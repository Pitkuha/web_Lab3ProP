create PROCEDURE dbms_feature_priv_capture
     ( feature_boolean  OUT NUMBER,
       aux_count        OUT NUMBER,
       feature_info     OUT CLOB)
AS
  cursor priv_capture is select id#, type,
                         CASE type
                           WHEN 1 THEN 'DATABASE'
                           WHEN 2 THEN 'ROLE'
                           WHEN 3 THEN 'CONTEXT'
                           WHEN 4 THEN 'ROLE_AND_CONTEXT'
                         END l_type
                         from sys.priv_capture$ where id# >= 5000;
  l_capture   priv_capture%ROWTYPE;
  feature_usage varchar2(1000) := NULL;
  l_prefix      varchar2(100) := NULL;
  l_count       number := 0;
begin
  -- initialize output parameters
  aux_count := 0;
  feature_boolean := 0;
  feature_info := NULL;

  -- total number of captures
  select count(*) into l_count from sys.priv_capture$ where id# >= 5000;

  if (l_count > 0) then
    -- feature is used if a capture is created
    feature_boolean := 1;
    aux_count := l_count;

    l_prefix := 'Number of privilege captures=' || to_char(l_count)
                || Chr(13) || Chr(10) || '(';

    -- Information for each capture
    for l_capture in priv_capture loop

        feature_usage := feature_usage || 'Type=' || l_capture.l_type;

        select count(*) into l_count from sys.capture_run_log$
        where capture = l_capture.id#;

        feature_usage := feature_usage || ' Number of Runs=' ||
                         to_char(l_count) || Chr(13) || Chr(10);
    end loop;
    feature_info := to_clob(l_prefix || feature_usage || ')');

  end if;
end dbms_feature_priv_capture;
/

