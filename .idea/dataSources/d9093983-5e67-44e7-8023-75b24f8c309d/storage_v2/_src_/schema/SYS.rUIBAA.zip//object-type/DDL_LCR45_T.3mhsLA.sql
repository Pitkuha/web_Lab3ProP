create TYPE       "DDL_LCR45_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","source_database_name" VARCHAR2(128 CHAR),"command_type" VARCHAR2(4000 CHAR),"current_schema" VARCHAR2(30 CHAR),"ddl_text" CLOB,"object_type" VARCHAR2(4000 CHAR),"object_owner" VARCHAR2(30 CHAR),"object_name" VARCHAR2(30 CHAR),"logon_user" VARCHAR2(30 CHAR),"base_table_owner" VARCHAR2(30 CHAR),"base_table_name" VARCHAR2(30 CHAR),"tag" RAW(2000),"transaction_id" VARCHAR2(4000 CHAR),"scn" NUMBER,"extra_attribute_values" "extra_attribute_values46_T")FINAL INSTANTIABLE
/

