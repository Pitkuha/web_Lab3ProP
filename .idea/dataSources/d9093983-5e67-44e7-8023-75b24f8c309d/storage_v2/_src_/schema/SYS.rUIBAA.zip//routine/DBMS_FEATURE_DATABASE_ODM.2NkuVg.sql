create procedure DBMS_FEATURE_DATABASE_ODM
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   dm_on              NUMBER;     -- data mining option on
   model_cnt          NUMBER;
   dm_usage           varchar2(32767);
begin
  -- initialize
  feature_boolean   := 0;
  aux_count         := 0;
  feature_info      := NULL;
  model_cnt         := 0;

  -- check if ODM option is installed
  select count(*) into dm_on from v$option where
     parameter = 'Data Mining' and value = 'TRUE';

  if (dm_on = 0) then
    return;
  end if;

   execute immediate
         'select count(*), listagg(feature,'';'') within group (order by feature) ' ||
     'from ( ' ||
       'with a as ( ' ||
        'select decode(func ' ||
          ',1, ''CLASSIFICATION'' ' ||
          ',2, ''REGRESSION'' ' ||
          ',3, ''CLUSTERING'' ' ||
          ',4, ''FEATURE_EXTRACTION''  ' ||
          ',5, ''ASSOCIATION_RULES''  ' ||
          ',6, ''ATTRIBUTE_IMPORTANCE''  ' ||
          ',0)||''(''||   ' ||
          ' decode(alg ' ||
          ',1, ''NAIVE_BAYES''  ' ||
          ',2, ''ADAPTIVE_BAYES_NETWORK''  ' ||
          ',3, ''DECISION_TREE''   ' ||
          ',4, ''SUPPORT_VECTOR_MACHINES''  ' ||
          ',5, ''KMEANS''   ' ||
          ',6, ''O_CLUSTER''  ' ||
          ',7, ''NONNEGATIVE_MATRIX_FACTOR''   ' ||
          ',8, ''GENERALIZED_LINEAR_MODEL''  ' ||
          ',9, ''APRIORI_ASSOCIATION_RULES''   ' ||
          ',10, ''MINIMUM_DESCRIPTION_LENGTH''   ' ||
          ',11, ''SINGULAR_VALUE_DECOMP''   ' ||
          ',12, ''EXPECTATION_MAXIMIZATION''    ' ||
          ',0)||'')'' feat from model$  ' ||
          'where (alg not in (4,5)) or  ' ||
          '(alg in (4,5) and obj# in (select mod# from modeltab$ where typ#=2))) ' ||
      'select feat||''(''||count(*)||'')'' feature from a group by feat order by count(*))'
       into model_cnt, dm_usage;

    if (model_cnt  > 0)   then     --- feature used
        feature_boolean := 1;
        aux_count := model_cnt;
        feature_info := TO_CLOB(dm_usage);
    else                        --- feature not used
        feature_boolean := 0;
        aux_count := 0;
        feature_info := null;
    end if;

END DBMS_FEATURE_DATABASE_ODM;
/

