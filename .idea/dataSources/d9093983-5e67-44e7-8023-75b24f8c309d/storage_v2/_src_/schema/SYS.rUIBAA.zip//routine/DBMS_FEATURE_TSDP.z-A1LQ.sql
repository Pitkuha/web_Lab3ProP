create procedure DBMS_FEATURE_TSDP
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage         varchar2(1000);
    num_sensitive_cols    number;
    num_policies          number;
    num_columns_protected number;
    num_sensitive_types   number;

begin
    -- initialize
    feature_boolean := 0;
    aux_count := 0;
    num_sensitive_cols := 0;
    num_policies := 0;
    num_columns_protected := 0;
    num_sensitive_types := 0;

    -- check if sensitive columns have been identified.
    execute immediate 'select count(*) from DBA_SENSITIVE_DATA'
        into num_sensitive_cols;

    -- check if Sensitive Column Types have been created.
    execute immediate 'select count(*) from DBA_SENSITIVE_COLUMN_TYPES'
            into num_sensitive_types;

    -- check if TSDP policies have been created.
    execute immediate 'select count(*) from DBA_TSDP_POLICY_FEATURE'
            into num_policies;

    -- check for protected sensitive columns.
    execute immediate 'select count(*) from DBA_TSDP_POLICY_PROTECTION'
            into num_columns_protected;

    -- Feature_usage information will contain:
    -- number of Sensitive Column Types created,
    -- number of TSDP policies created, and
    -- number of Sensitive Columns protected using TSDP.
    -- Note: Number of Sensitive Columns identified is not shown here
    --       as it is a sensitive metric.
    feature_usage :=
                'Number of Sensitive Column Types created: ' ||
                 to_char(num_sensitive_types) ||
        ', ' || 'Number of TSDP policies created: ' ||
                 to_char(num_policies) ||
        ', ' || 'Number of Sensitive Columns protected using TSDP: ' ||
                 to_char(num_columns_protected)
        ;

    -- In order to conclude that TSDP is in use, we check if
    --   atleast one Sensitive Column Type is created,
    --   OR if atleast one column identified as sensitive,
    --   OR atleast two TSDP policies exist. (Note that
    --      REDACT_AUDIT policy is created by default,
    --      and this policy cannot be dropped).
    if ((num_sensitive_cols > 0) or (num_sensitive_types > 0)
        or (num_policies > 1))
     then
       feature_boolean := 1;
       feature_info := to_clob(feature_usage);

    else
       feature_info := to_clob('Transparent Sensitive Data Protection ' ||
                               'feature not used');

    end if;

end;
/

