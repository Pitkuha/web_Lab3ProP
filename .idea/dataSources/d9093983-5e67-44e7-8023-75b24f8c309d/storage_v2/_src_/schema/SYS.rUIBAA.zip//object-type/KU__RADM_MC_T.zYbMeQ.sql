create type ku$_radm_mc_t as object
(
  vers_major  char(1),                                /* UDT major version # */
  vers_minor  char(1),                                /* UDT minor version # */
  obj_num     number,                      /* object number of table or view */
  intcol_num  number,                                       /* column number */
  col_name    varchar2(30),                                   /* column name */
  pname       varchar2(30),                                   /* policy name */
  mfunc       number,                   /* RADM masking function (KZRADMMF_) */
  mparams     varchar2(1000)                      /* RADM masking parameters */
)
/

