create type ku$_option_objnum_t as object
(
  obj_num       number,                                              /* obj# */
  table_type    varchar2(1),         /* 'T' = base table, 'N' = nested table */
                                  /* 'X' = nested table belonging to XMLtype */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  tgt_type      number,                                             /* type# */
  impc_flags    number,           /* export processing flags: See dtools.bsq */
  tag           varchar2(30)                    /* optional group identifier */
)
/

