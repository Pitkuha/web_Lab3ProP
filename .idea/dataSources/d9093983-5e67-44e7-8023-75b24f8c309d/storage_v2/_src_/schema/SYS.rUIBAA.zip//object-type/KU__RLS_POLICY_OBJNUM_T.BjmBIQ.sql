create type ku$_rls_policy_objnum_t as object
(
  obj_num       number,                               /* parent object number */
  name          varchar2(30),                         /* name of policy */
  pfschma       varchar2(30),               /* name of policy function schema */
  ppname        varchar2(30),               /* name of policy package */
  pfname        varchar2(30),               /* name of policy function name */
  base_obj      ku$_schemaobj_t                       /* base schema object */
)
/

