create TYPE     aq$_reg_info AS OBJECT (
        name                  VARCHAR2(128),  -- name of the subscription
        namespace             NUMBER,         -- namespace of the subscription
        callback              VARCHAR2(4000), -- callback function
        context               RAW(2000),      -- context for the callback func.
        anyctx                SYS.ANYDATA,    -- anydata ctx for callback func
        ctxtype               NUMBER,         -- raw/anydata context
        qosflags              NUMBER,         -- QOS flags
        payloadcbk            VARCHAR2(4000), -- payload callback
        timeout               NUMBER,         -- registration expiration
        ntfn_grouping_class        NUMBER,    -- ntfn grouping class
        ntfn_grouping_value        NUMBER,    -- ntfn grouping value
        ntfn_grouping_type         NUMBER,    -- ntfn grouping type
        ntfn_grouping_start_time   TIMESTAMP WITH TIME ZONE, -- grp start time
        ntfn_grouping_repeat_count NUMBER,    -- ntfn grp repeat count
        CONSTRUCTOR FUNCTION aq$_reg_info(
          name             VARCHAR2,
          namespace        NUMBER,
          callback         VARCHAR2,
          context          RAW)
        RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION aq$_reg_info(
          name             VARCHAR2,
          namespace        NUMBER,
          callback         VARCHAR2,
          context          RAW,
          anyctx           SYS.ANYDATA,
          ctxtype          NUMBER)
        RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION aq$_reg_info(
          name             VARCHAR2,
          namespace        NUMBER,
          callback         VARCHAR2,
          context          RAW,
          qosflags         NUMBER,
          timeout          NUMBER)
        RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION aq$_reg_info(
          name             VARCHAR2,
          namespace        NUMBER,
          callback         VARCHAR2,
          context          RAW,
          anyctx           SYS.ANYDATA,
          ctxtype          NUMBER,
          qosflags         NUMBER,
          payloadcbk       VARCHAR2,
          timeout          NUMBER)
        RETURN SELF AS RESULT,
        CONSTRUCTOR FUNCTION aq$_reg_info(
          name                       VARCHAR2,
          namespace                  NUMBER,
          callback                   VARCHAR2,
          context                    RAW,
          qosflags                   NUMBER,
          timeout                    NUMBER,
          ntfn_grouping_class        NUMBER,
          ntfn_grouping_value        NUMBER,
          ntfn_grouping_type         NUMBER,
          ntfn_grouping_start_time   TIMESTAMP WITH TIME ZONE,
          ntfn_grouping_repeat_count NUMBER)
        RETURN SELF AS RESULT
        );
/

