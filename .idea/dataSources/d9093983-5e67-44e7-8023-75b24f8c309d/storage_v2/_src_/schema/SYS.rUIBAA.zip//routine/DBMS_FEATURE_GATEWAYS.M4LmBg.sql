create PROCEDURE DBMS_FEATURE_GATEWAYS
    ( feature_boolean OUT NUMBER,
      aux_count        OUT NUMBER,
      feature_info    OUT CLOB )
AS
  TYPE GtwCursorRef is REF CURSOR;
  TYPE ResultList   is TABLE of varchar(150);
  cur GtwCursorRef;
  res ResultList;
  hs_sql varchar(250);
  i number;
BEGIN
 /*
 We are using "execute immediate" to query HS tables
 because they are not present at the moment this
 stored procedure is created.
 */

  hs_sql := 'select count(*)  ' ||
            '  from   HS_FDS_CLASS '        ||
            '  where fds_class_name <> ''BITE''';
  execute immediate hs_sql into aux_count;

  feature_boolean := aux_count;

  if aux_count = 0
  then
    feature_info := 'This feature is not used.';

    return;
  end if;

  feature_info := 'Num of FDS classes:' || aux_count;

  open cur for 'select ''(ID:''  || FDS_CLASS_ID || ''' ||
               ',NAME:'' || FDS_CLASS_NAME || '',' ||
               'COMMENTS:'' || substr(FDS_CLASS_COMMENTS, 1, 110) || '')''' ||
               ' from HS_FDS_CLASS where FDS_CLASS_NAME <> ''BITE''';
  fetch cur bulk collect into res;
  close cur;

  for i in res.FIRST .. res.LAST loop
    feature_info := feature_info || ',' || res(i);
    /* make sure we don't reach the 1000 chars limit */
    if LENGTH(feature_info) > 850
    then
      feature_info := feature_info || '...';
      return;
    end if;
  end loop;

  hs_sql := 'select count(*)  ' ||
            '  from   HS_FDS_INST '        ||
            '  where fds_class_name <> ''BITE''';
  execute immediate hs_sql into i;

  feature_info := feature_info || ',Num of FDS instances:' || i;

  if i > 0 then
    open cur for 'select ''(CLASS:''  || FDS_CLASS_ID || '',ID:'' || ' ||
                 'FDS_INST_ID || '',NAME:'' || FDS_INST_NAME || ' ||
                 ''',COMMENTS:'' || substr(FDS_INST_COMMENTS, 1, 110)' ||
                 ' || '')'' from HS_FDS_INST where FDS_CLASS_NAME <> ''BITE''';
    fetch cur bulk collect into res;
    close cur;

    for i in res.FIRST .. res.LAST loop
      feature_info := feature_info || ',' || res(i);
      /* make sure we don't reach the 1000 chars limit */
      if LENGTH(feature_info) > 850
      then
        feature_info := feature_info || '...';
        return;
      end if;
    end loop;
  end if;
END;
/

