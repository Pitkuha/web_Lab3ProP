create type ku$_audit_policy_enable_t as object (
  policy_num    number,
  schema_obj    ku$_schemaobj_t,                            /* policy object */
  "USER"        varchar2(128),                       /* NULL for 'ALL USERS' */
  when_opt      number,                /* 1 - Success, 2 - Failure, 3 - Both */
  how_opt       number)                                /* 1 - By, 2 - Except */

