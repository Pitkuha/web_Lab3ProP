create TYPE HS_PART_OBJ  authid current_user AS OBJECT
 (low_value sys.HSBLKValAry,
 high_value sys.HSBLKValAry,
 col_name    sys. HSBLKNamLst,
 col_type     sys.HSBLKNamLst ,
 position   number);
/

