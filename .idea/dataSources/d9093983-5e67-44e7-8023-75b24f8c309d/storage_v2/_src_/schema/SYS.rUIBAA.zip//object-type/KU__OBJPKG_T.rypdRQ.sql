create type ku$_objpkg_t as object
(
  package       varchar2(30),                     /* procedural package name */
  schema        varchar2(30)                               /* package schema */
)
/

