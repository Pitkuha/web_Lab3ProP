create type dbms_xplan_type
  as object (plan_table_output varchar2(300));
/

