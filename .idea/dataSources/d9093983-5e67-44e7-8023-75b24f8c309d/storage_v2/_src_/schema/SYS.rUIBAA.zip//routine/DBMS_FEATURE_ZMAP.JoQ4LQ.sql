create PROCEDURE dbms_feature_zmap
      (is_used OUT number, zmap_ratio OUT number, clob_rest OUT clob)
AS
BEGIN
  -- initialize
  is_used := 0;
  zmap_ratio := 0;
  clob_rest := '{ "data": [';

FOR crec IN (SELECT
       -- zone map existent
       DECODE(xx.sumobj#,NULL,'N','Y') zmap_used,
       '{ ' ||
       -- zone map existent
       CASE WHEN xx.sumobj# IS NOT NULL THEN
         '"zmap": { '       ||
--         '"zmap":"'       || DECODE(xx.sumobj#,NULL,'N','Y')  ||'",' ||
         '"zm_w_attrcl":"' || DECODE(bitand(xx.cflags,8),8,'Y','N') ||'",' ||
         '"joined_zmap":"' || DECODE(bitand(xx.xpflags,137438953472),137438953472,'Y','N') || '",' ||
         '"zm_scale":'     || zmapscale     || ','||
         '"num_joins":'    || numjoins      || ','||
         '"num_tabs":'     || numdetailtab  || ','||
         '"num_cols":'     || (numaggregates - numjoins-1)/2 || ','||
         '"refresh_mode":"'|| DECODE(bitand(mflags,65536),65536,'C',
                                     DECODE(bitand(mflags,34359738368+68719476736),34359738368+68719476736,'L+M',
                                            34359738368,'L', 68719476736,'M','D'))    || '",'||
         '"disabled":"'    || DECODE(bitand(mflags,4),4,'Y','N')                      || '",'||
         '"unusable":"'    || DECODE(bitand(mflags,17179869184),17179869184,'Y','N')  || '",'||
         '"invalid":"'     || DECODE(bitand(mflags,64),64,'Y','N')                    || '",'||
         '"stale":"'       || DECODE(bitand(mflags,16+32),0,'Y','N')                  || '"},'
       END ||
       -- attribute clustering existent
       CASE WHEN xx.clstobj# IS NOT NULL THEN
         '"attrcl":{ '      ||
--         '"attrcl":"'      || DECODE(xx.clstobj#,NULL,'N','Y') ||'",' ||
         '"clst_type":"'    || DECODE(clstfunc,1,'I','L')                                 || '",'||
         '"clst_mode":"'    || DECODE(bitand(xx.cflags,1+2),1+2,'L+M',1,'L',2,'M','OFF')  || '",'||
         '"clst_dim":'      || (SELECT COUNT(*) FROM clstdimension$ d
                                WHERE d.clstobj#(+)=xx.clstobj#)                          || ','||
         '"clst_grp":'     || (SELECT COUNT(DISTINCT groupid) FROM clstkey$ k
                                       WHERE k.clstobj#(+)=xx.clstobj#)                   || ','||
         '"clst_cols":'     || (SELECT COUNT(*) FROM clstkey$ k
                                        WHERE k.clstobj#(+)=xx.clstobj#)                  || ','||
         '"clst_invalid":"' || DECODE(bitand(xx.flags,4),4,'Y','N')                       || '"},'
       END ||
       '"tab":{'    ||
       CASE
       WHEN bitand(xx.property,32) = 32 THEN
         '"parttab":"Y"'
       -- nonpartitioned tables with existing segments
       WHEN s.block# IS NOT NULL THEN
          '"parttab":"N",' ||
           '"imc_prio":"'      ||
           DECODE(bitand(s.spare1, 4294967296), 4294967296,
                 DECODE(bitand(s.spare1, 34359738368), 34359738368,
                        DECODE(bitand(s.spare1, 3848290697216), 549755813888,'LOW',
                                                               1099511627776,'MEDIUM',
                                                               2199023255552,'HIGH',
                                                               3298534883328,'CRITICAL','NONE'),'NONE'),'-')  || '",'||
          '"imc_dist":"'       ||
          DECODE(bitand(s.spare1, 4294967296), 4294967296,
                 DECODE(bitand(s.spare1, 8589934592),0,'DUPLICATE','AUTO DIST'),'-')                          || '",'||
          '"imc_comp":"'       ||
          DECODE(bitand(s.spare1, 4294967296), 4294967296,
                 DECODE(bitand(s.spare1, 274877906944), 0,
                       DECODE(bitand(s.spare1,17179869184),0,'BASIC','QUERY'),
                              DECODE(bitand(s.spare1,17179869184),0,'CAP LOW','CAP HIGH')),'-') ||'"'
          ELSE
          '"parttab":"N"'
      END
      || '} }' zmap_obj
FROM (SELECT *
      FROM (SELECT sumobj#, clstobj#, detailobj#, mflags, c.flags as cflags, clstfunc, numjoins,
                   numaggregates, numdetailtab, zmapscale, xpflags
            FROM ( SELECT sumobj#, detailobj#, mflags, numjoins, numaggregates, numdetailtab,
                          zmapscale, xpflags
                   FROM sum$ s
                            RIGHT OUTER JOIN sumdetail$ sd
                            ON (s.obj# = sd.sumobj#)
                            WHERE bitand(s.xpflags,34359738368)=34359738368
                            AND bitand(sd.flags,2) = 2
                  ) zm
            -- to accommodate either-or for zone maps or attribute clustering
            FULL OUTER JOIN clst$ c
            ON (zm.detailobj# = c.clstobj#)
            ) x
            JOIN tab$ t
            ON (t.obj#=DECODE(x.clstobj#,NULL,x.detailobj#,x.clstobj#))
     ) xx
     -- needed for deferred segments and partitioned objects
     LEFT OUTER JOIN seg$ s
     ON (xx.file#  = s.file#
     AND xx.block# = s.block#
     AND xx.ts#    = s.ts#)) loop

     IF (is_used = 0 AND crec.zmap_used= 'Y') THEN
       is_used:=1;
     END IF;

 clob_rest := clob_rest || crec.zmap_obj ||', ';
 END LOOP;

 clob_rest := substr(clob_rest,1,length(clob_rest)-2) ||' ] }';

   IF (is_used = 1) THEN
      -- ratio of tables with zone maps versus total # of tables in percent
      SELECT (COUNT(detailobj#)/COUNT(obj#))*100 INTO zmap_ratio
      FROM ( SELECT detailobj#
             FROM sum$ s
             JOIN sumdetail$ sd
       ON (s.obj# = sd.sumobj#)
       WHERE bitand(s.xpflags,34359738368)=34359738368
       AND bitand(sd.flags,2) = 2
       ) zm
      RIGHT OUTER JOIN tab$ t
      ON (t.obj#=zm.detailobj#);
   END IF;

 END;
/

