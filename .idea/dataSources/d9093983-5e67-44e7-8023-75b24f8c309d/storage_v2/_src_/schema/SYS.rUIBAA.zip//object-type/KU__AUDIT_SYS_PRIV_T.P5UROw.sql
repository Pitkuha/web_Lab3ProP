create type ku$_audit_sys_priv_t as object (
        PRIVILEGE     number,
        NAME          varchar2(40),
        PROPERTY      number          /* 0x01 = do not export this privilege */
                                      /* using sql statements */
  )
/

