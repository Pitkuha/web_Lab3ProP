create PROCEDURE ODCIPartInfoDump(pinfo IN SYS.ODCIPartInfo) IS
BEGIN
  dbms_output.put_line('ODCIPartInfo :');
  dbms_output.put_line('Table partition name : ' || pinfo.TablePartition);
  dbms_output.put_line('Index partition name : ' || pinfo.IndexPartition);
  dbms_output.put_line('Index partition iden : ' || pinfo.IndexPartitionIden);

  IF (pinfo.PartOp = ODCIConst.AddPartition) THEN
    dbms_output.put_line('Add Partition');
  ELSIF (pinfo.PartOp = ODCIConst.DropPartition) THEN
    dbms_output.put_line('Drop Partition');
  END IF;
END;
/

