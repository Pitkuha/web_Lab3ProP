create type ku$_rls_associations_t as object
(
  obj_num       number,                              /* parent object number */
  gname         varchar2(30),                        /* name of policy group */
  name          varchar2(30),                              /* name of policy */
  namespace     varchar2(30),                                   /* namespace */
  attribute     varchar2(30)                                    /* attribute */
)
/

