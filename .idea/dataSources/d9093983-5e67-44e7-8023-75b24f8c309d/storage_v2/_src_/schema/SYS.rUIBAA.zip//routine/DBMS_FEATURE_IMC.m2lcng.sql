create procedure DBMS_FEATURE_IMC(
    feature_boolean OUT NUMBER,
    aux_count       OUT NUMBER,
    feature_info    OUT CLOB)
AS
    feature_usage               varchar2(1000);
    num_tab                     number;
    num_tab_part                number;
    num_tab_subpart             number;
    num_segs                    number;

BEGIN
    feature_boolean             := 0;
    aux_count                   := 0;

    execute immediate
       'select count(*) from dba_tables where ' ||
       'inmemory_compression is not null'
    into num_tab;

    execute immediate
       'select count(*) from dba_tab_partitions where ' ||
       'inmemory_compression is not null'
    into num_tab_part;

    execute immediate
       'select count(*) from dba_tab_subpartitions where ' ||
       'inmemory_compression is not null'
    into num_tab_subpart;

    -- This query will catch the case where tables are
    -- created with inmemory_default=FORCE. In that case
    -- the tables created will have the 'inmemory_compression'
    -- field as null. The above queries are still required
    -- since a table could have been created as 'INMEMORY',
    -- but not have been loaded into memory yet. segtype=0
    -- will exclude in-memory journal areas.
    execute immediate
       'select count(*) from gv$im_segments_detail where ' ||
       'segtype=0'
    into num_segs;

    --Summary
    feature_usage :=
        ' In-Memory Column Store Feature Usage: ' ||
                'In-Memory Column Store Tables: ' ||
                  to_char(num_tab) ||
        ', ' || 'In-Memory Column Store Table Partitions: ' ||
                  to_char(num_tab_part) ||
        ', ' || 'In-Memory Column Store Table Subpartitions: ' ||
                  to_char(num_tab_subpart) ||
        ', ' || 'Total In-Memory Column Store Segments Populated: ' ||
                  to_char(num_segs);

     if (num_tab + num_tab_part + num_tab_subpart + num_segs > 0) then
      feature_boolean := 1;
      feature_info := to_clob(feature_usage);
    else
      feature_boolean := 0;
      feature_info := to_clob('In-Memory Column Store Not Detected');
    end if;
END;
/

