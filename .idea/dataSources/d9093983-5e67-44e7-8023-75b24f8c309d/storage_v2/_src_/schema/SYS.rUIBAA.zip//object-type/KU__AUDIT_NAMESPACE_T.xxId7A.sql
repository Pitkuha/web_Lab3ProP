create type ku$_audit_namespace_t as object (
  namespace     varchar2(128),
  aud_attr      ku$_audit_attr_list_t)
/

