create type ku$_objpkg_privs_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  package       varchar2(30),                  /* procedural package objects */
  schema        varchar2(30),                              /* package schema */
  plsql         ku$_procobj_lines      /* PL/SQL code for proc sys privilege */
)
/

