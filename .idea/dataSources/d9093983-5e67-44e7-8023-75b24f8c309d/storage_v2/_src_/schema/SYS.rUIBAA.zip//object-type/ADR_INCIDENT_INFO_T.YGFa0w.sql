create TYPE adr_incident_info_t AS OBJECT
(
  problem_key             VARCHAR2(64),        /* problem key of the incident */
  error_facility          VARCHAR2(10),                     /* error facility */
  error_number            INTEGER,                            /* error number */
  error_message           VARCHAR2(1024),                    /* error message */
  ecid                    VARCHAR2(64),               /* execution context id */
  signalling_component    VARCHAR2(64),               /* signalling component */
  signalling_subcomponent VARCHAR2(64),           /* signalling sub component */
  suspect_component       VARCHAR2(64),                  /* suspect component */
  suspect_subcomponent    VARCHAR2(64),              /* suspect sub component */
  error_args              adr_incident_err_args_t,         /* error arguments */
  correlation_keys        adr_incident_corr_keys_t,       /* correlation keys */
  files                   adr_incident_files_t   /* additional incident files */
);
/

