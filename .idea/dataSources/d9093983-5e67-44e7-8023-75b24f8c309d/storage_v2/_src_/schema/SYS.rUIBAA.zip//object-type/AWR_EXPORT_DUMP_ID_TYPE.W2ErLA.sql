create TYPE AWR_EXPORT_DUMP_ID_TYPE
  AS
    OBJECT (
      src_name        VARCHAR2(30)
    , src_dbid        NUMBER
    , begin_snap      NUMBER
    , end_snap        NUMBER
    , db_name         VARCHAR2(30)
    , db_version      VARCHAR2(17)
    , wr_version      NUMBER
   )
/

