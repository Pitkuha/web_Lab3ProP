create type dm_svd_matrix
                                       as object
  (matrix_type           CHAR(1)
  ,feature_id            NUMBER
  ,mapped_feature_id     VARCHAR2(4000)
  ,attribute_name        VARCHAR2(4000)
  ,attribute_subname     VARCHAR2(4000)
  ,case_id               VARCHAR2(4000)
  ,value                 NUMBER
  ,variance              number
  ,pct_cum_variance      NUMBER
  )
/

