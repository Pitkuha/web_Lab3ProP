create procedure     subptxt(name varchar2, subname varchar2, usr varchar2,
                             txt in out varchar2) is
begin
    subptxt2(name, subname, usr, null, null, txt);
end;
/

