create PROCEDURE ODCIPartInfoListDump(plist IN SYS.ODCIPartInfoList)
IS
 col NUMBER;
BEGIN
 dbms_output.put_line('ODCIPartInfoList :');
 FOR col IN plist.FIRST..plist.LAST LOOP
  dbms_output.put_line('ODCIPartInfo (' || col || ') :');
  ODCIPartInfoDump(plist(col));
 END LOOP;
END;
/

