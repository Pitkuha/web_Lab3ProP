create type ku$_defrole_item_t as object
(
  user_id       number,                                          /* user id  */
  user_name     varchar2(30),                                   /* user name */
  role          varchar2(30),                            /* role source name */
  role_id       number                                            /* role id */
)
/

