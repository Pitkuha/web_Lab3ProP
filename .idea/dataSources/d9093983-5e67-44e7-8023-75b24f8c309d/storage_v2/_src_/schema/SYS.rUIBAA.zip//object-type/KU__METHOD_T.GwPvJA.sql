create type ku$_method_t as object
(
  toid           raw(16),                                            /* TOID */
  version_num    number,                     /* internal type version number */
  method_num     number,                        /* method number or position */
  name           varchar2(30),                                /* method name */
  properties     number,                             /* method's properties: */
  /* 0x00001 =      1 = PRIVATE method */
  /* 0x00002 =      2 = PUBLIC method (default) */
  /* 0x00004 =      4 = INLINE method */
  /* 0x00008 =      8 = VIRTUAL method => NOT FINAL */
  /* 0x00010 =     16 = CONSTANT method */
  /* 0x00020 =     32 = contructor method */
  /* 0x00040 =     64 = destructor method */
  /* 0x00080 =    128 = operator method */
  /* 0x00100 =    256 = selfish method */
  /* 0x00200 =    512 = MAP method */
  /* 0x00800 =   2048 = ORDER method */
  /* 0x01000 =   4096 = Read No Data State method (default) */
  /* 0x02000 =   8192 = Write No Data State method */
  /* 0x04000 =  16384 = Read No Process State method */
  /* 0x08000 =  32768 = Write No Process State method */
  /* 0x10000 =  65536 = Not Instantiable method */
  /* 0x20000 = 131072 = Overriding method */
  /* 0x40000 = 262144 = Returns SELF as result */
  parameters_num number,                             /* number of parameters */
  results        number,                                /* number of results */
  xflags         number,                          /* Flags not stored in TDO */
  /* 0x01 - Inherited method */
  spare1         number,                                         /* reserved */
  spare2         number,                                         /* reserved */
  spare3         number,                                         /* reserved */
  externVarName  varchar2(114),   /*"M_VCSZ" external variable name for SQLJ */
  argument_list  ku$_argument_list_t,            /* argument list for method */
  procedureinfo  ku$_procinfo_t,                           /* procedure info */
  procjava       ku$_procjava_t,                       /*java procedure info */
  procplsql      ku$_procplsql_t,                     /*plsql procedure info */
  procc          ku$_procc_t,                             /*C procedure info */
  obj_num        number
)
/

