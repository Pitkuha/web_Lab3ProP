create type ku$_fba_period_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                        /* table obj# */
  periodname    varchar2(255),                                /* period name */
  flags         number,
  periodstart   varchar2(255),
  periodend     varchar2(255),
  spare         number
)
/

