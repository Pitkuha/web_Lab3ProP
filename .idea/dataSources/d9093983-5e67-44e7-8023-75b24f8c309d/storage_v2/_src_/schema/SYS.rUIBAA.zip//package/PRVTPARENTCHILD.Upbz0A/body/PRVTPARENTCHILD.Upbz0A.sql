create package body PrvtParentChild
IS

Function getParentIDFromModelID
       ( modelID IN varchar2 )
       RETURN PARENTIDARRAY
    IS
       parentElementID PARENTIDARRAY := PARENTIDARRAY();
       cur0 refCursor;
       pID RAW(200);
       sqlStmtBase varchar2(2000);
       sqlStmt varchar2(2000);
       counter number(38);
       complexID varchar2(200);
       BEGIN
    sqlStmtBase := 'from xdb.xdb$complex_type ct where ( sys_op_r2o(ct.xmldata.all_kid) =';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.choice_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.sequence_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.extension.sequence_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.extension.choice_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.extension.all_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.extension.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.restriction.sequence_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.restriction.choice_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.restriction.all_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.restriction.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
    sqlStmtBase := sqlStmtBase || ' )';

    sqlStmt := ' select count(*) ' || sqlStmtBase;
    EXECUTE IMMEDIATE sqlStmt INTO counter ;
    IF (counter <> 0) THEN
        sqlStmt := 'select ct.sys_nc_oid$ ' || sqlStmtBase;
        EXECUTE IMMEDIATE sqlStmt INTO complexID ;

        sqlStmt := ' select hextoraw(e.xmldata.property.prop_number) from xdb.xdb$element e where sys_op_r2o(e.xmldata.property.type_ref) = ';
        sqlStmt := sqlStmt || Dbms_Assert.Enquote_Literal(complexID);
        sqlStmt := sqlStmt ;
        counter := 1;
        OPEN cur0 FOR sqlStmt;
        LOOP
             FETCH cur0 INTO pID;
             EXIT WHEN cur0%NOTFOUND;
             parentElementID.extend;
             parentElementID(counter) := pID;
             counter := counter + 1;
        END LOOP;
        CLOSE cur0;
        RETURN parentElementID;
    ELSE
       RETURN NULL;
    END IF;


    RETURN parentElementID;
    EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
    END;

Function getParentIDFromGroupID
       ( groupID IN varchar2 )
       RETURN PARENTIDARRAY
    IS
       modelID varchar2(200);
       complexID varchar2(200);
       counter number(38);
       sqlStmtBase varchar2(2000);
       sqlStmt varchar2(2000);
       seqKid boolean := FALSE;
       choiceKid boolean := FALSE;
       allKid boolean := FALSE;
       kidClause varchar2(100);
       elementID varchar2(200);
       parentElementID PARENTIDARRAY := PARENTIDARRAY();
       cur0 refCursor;
       pID RAW(200);
    BEGIN
    counter := 0;
       -- Get the reference ID from the def ID
       select count(*) INTO counter from xdb.xdb$group_ref rg, xdb.xdb$group_def dg where ref(dg) = rg.xmldata.groupref_ref and dg.sys_nc_oid$= groupID;
       IF (counter <> 0) THEN
          select rg.sys_nc_oid$ INTO elementID from xdb.xdb$group_ref rg, xdb.xdb$group_def dg where ref(dg) = rg.xmldata.groupref_ref and dg.sys_nc_oid$= groupID;
       ELSE
          RETURN NULL;
       END IF;
       -- choice
      sqlStmtBase := 'from xdb.xdb$choice_model sm, table(sm.xmldata.groups) t where sys_op_r2o(t.column_value) = ';
      sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
      sqlStmt := ' select count(*) ' || sqlStmtBase;
       EXECUTE IMMEDIATE sqlStmt INTO counter ;
       IF ( counter <> 0 ) THEN
           sqlStmt := ' select sm.sys_nc_oid$ ' || sqlStmtBase;
           EXECUTE IMMEDIATE sqlStmt INTO modelID ;
           choiceKid := TRUE;
       ELSE
      sqlStmtBase := 'from xdb.xdb$sequence_model sm, table(sm.xmldata.groups) t where sys_op_r2o(t.column_value) = ';
      sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
      sqlStmt := ' select count(*) ' || sqlStmtBase;
       EXECUTE IMMEDIATE sqlStmt INTO counter ;
          IF ( counter <> 0 ) THEN

           sqlStmt := ' select sm.sys_nc_oid$ ' || sqlStmtBase;
           EXECUTE IMMEDIATE sqlStmt INTO modelID ;
            seqKid := TRUE;
          ELSE
      sqlStmtBase := 'from xdb.xdb$all_model sm, table(sm.xmldata.groups) t where sys_op_r2o(t.column_value) = ';
      sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
      sqlStmt := ' select count(*) ' || sqlStmtBase;
            IF ( counter <> 0 ) THEN

           sqlStmt := ' select sm.sys_nc_oid$ ' || sqlStmtBase;
           EXECUTE IMMEDIATE sqlStmt INTO modelID ;
                allKid := TRUE;
            ELSE
               -- could be a direct child
    sqlStmtBase := 'from xdb.xdb$complex_type ct where ( ';
    sqlStmtBase := sqlStmtBase || '  sys_op_r2o(ct.xmldata.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.extension.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
    sqlStmtBase := sqlStmtBase || ' OR sys_op_r2o(ct.xmldata.complexcontent.restriction.group_kid) = ';
    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(elementID);
    sqlStmtBase := sqlStmtBase || ' )';

    sqlStmt := ' select count(*) ' || sqlStmtBase;
    DBMS_OUTPUT.PUT_LINE ( sqlStmt);
    EXECUTE IMMEDIATE sqlStmt INTO counter ;
    IF (counter <> 0) THEN
        sqlStmt := 'select ct.sys_nc_oid$ ' || sqlStmtBase;
        EXECUTE IMMEDIATE sqlStmt INTO complexID ;

        sqlStmt := ' select hextoraw(e.xmldata.property.prop_number) from xdb.xdb$element e where sys_op_r2o(e.xmldata.property.type_ref) = ';
        sqlStmt := sqlStmt || Dbms_Assert.Enquote_Literal(complexID);
        sqlStmt := sqlStmt ;

        counter := 1;
        OPEN cur0 FOR sqlStmt;
        LOOP
             FETCH cur0 INTO pID;
             EXIT WHEN cur0%NOTFOUND;
             parentElementID.extend;
             parentElementID(counter) := pID;
             counter := counter + 1;
        END LOOP;
        CLOSE cur0;
        RETURN parentElementID;
    ELSE
       RETURN NULL;
    END IF;
            END IF;
        END IF;
       END IF;

       sqlStmtBase := '';
       WHILE TRUE
       LOOP

            IF (seqKid = TRUE) THEN kidClause := 'sequence_kids';
            ELSIF (choiceKid = TRUE) THEN kidClause := 'choice_kids';
            ELSE RETURN getParentIDFromModelID(modelID);
            END IF;

            counter := 0;
            sqlStmtBase := 'table(sm.xmldata.' || kidClause || ')t where sys_op_r2o(t.column_value) = ';
            sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
            sqlStmt := 'select count(*) from xdb.xdb$choice_model sm, ' || sqlStmtBase;
            EXECUTE IMMEDIATE sqlStmt INTO counter  ;
            IF (counter <> 0) THEN
              sqlStmt := 'select sm.sys_nc_oid$ from xdb.xdb$choice_model sm, ' || sqlStmtBase;
              EXECUTE IMMEDIATE sqlStmt INTO modelID ;
              choicekid := TRUE; seqKid := FALSE; allKid := FALSE;
            ELSE
              sqlStmt := 'select count(*)   from xdb.xdb$sequence_model sm, ' || sqlStmtBase;
              EXECUTE IMMEDIATE sqlStmt INTO counter;
              IF (counter <> 0) THEN
                 sqlStmt := 'select sm.sys_nc_oid$  from xdb.xdb$sequence_model sm, ' || sqlStmtBase;
                 EXECUTE IMMEDIATE sqlStmt INTO modelID ;
                 choicekid := FALSE; seqKid := TRUE; allKid := FALSE;
              ELSE
                 sqlStmt := 'select count(*)  from xdb.xdb$all_model sm, ' || sqlStmtBase;
                 EXECUTE IMMEDIATE sqlStmt INTO counter ;
                 IF (counter <> 0) THEN
                    sqlStmt := 'select sm.sys_nc_oid$   from xdb.xdb$all_model sm, ' || sqlStmtBase;
                    EXECUTE IMMEDIATE sqlStmt INTO modelID;
                    choicekid := FALSE; seqKid := FALSE; allKid := TRUE;
                 ELSE -- group
                       RETURN getParentIDFromModelID(modelID);
                 END IF;
              END IF;
           END IF;
       END LOOP;

    RETURN NULL;
    EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
END;

Function getParentID
       ( elementID IN varchar2 )
       RETURN PARENTIDARRAY
    IS
       modelID varchar2(200);
       complexID varchar2(200);
       counter number(38);
       sqlStmtBase varchar2(2000);
       sqlStmt varchar2(2000);

       seqKid boolean := FALSE;
       choiceKid boolean := FALSE;
       allKid boolean := FALSE;
       kidClause varchar2(100);
    BEGIN
    counter := 0;
       -- choice
       select count(*) INTO counter from xdb.xdb$element e, xdb.xdb$choice_model sm,
       table(sm.xmldata.elements)t where ref(e) = t.column_value and e.xmldata.property.prop_number = elementID ;
       IF ( counter <> 0 ) THEN
           select sm.sys_nc_oid$ INTO modelID from xdb.xdb$element e, xdb.xdb$choice_model sm, table(sm.xmldata.elements)t where
           ref(e) = t.column_value and e.xmldata.property.prop_number =  elementID ;
           choiceKid := TRUE;
       ELSE
          -- sequence
          select count(*) INTO counter from xdb.xdb$element e, xdb.xdb$sequence_model sm,
          table(sm.xmldata.elements)t where ref(e) = t.column_value and e.xmldata.property.prop_number = elementID ;
          IF ( counter <> 0 ) THEN
            select sm.sys_nc_oid$ INTO modelID from xdb.xdb$element e, xdb.xdb$sequence_model sm, table(sm.xmldata.elements)t where
            ref(e) = t.column_value and e.xmldata.property.prop_number =  elementID ;
            seqKid := TRUE;
          ELSE
            -- all
            select count(*) INTO counter from xdb.xdb$element e, xdb.xdb$all_model sm,
            table(sm.xmldata.elements)t where ref(e) = t.column_value and e.xmldata.property.prop_number =  elementID ;
            IF ( counter <> 0 ) THEN
                select sm.sys_nc_oid$ INTO modelID from xdb.xdb$element e, xdb.xdb$all_model sm, table(sm.xmldata.elements)t where
                ref(e) = t.column_value and e.xmldata.property.prop_number =  elementID ;
                allKid := TRUE;
            ELSE
               RETURN NULL;
            END IF;
        END IF;
       END IF;

       WHILE TRUE
       LOOP
            IF (seqKid = TRUE) THEN kidClause := 'sequence_kids';
            ELSIF (choiceKid = TRUE) THEN kidClause := 'choice_kids';
            ELSE RETURN getParentIDFromModelID(modelID);
            END IF;

            counter := 0;
            sqlStmtBase := 'table(sm.xmldata.' || kidClause || ')t where sys_op_r2o(t.column_value) = ';
            sqlStmtBase := sqlStmtBase ||  Dbms_Assert.Enquote_Literal(modelID);
            sqlStmt := 'select count(*) from xdb.xdb$choice_model sm, ' || sqlStmtBase;
            EXECUTE IMMEDIATE sqlStmt INTO counter  ;
            IF (counter <> 0) THEN
              sqlStmt := 'select sm.sys_nc_oid$ from xdb.xdb$choice_model sm, ' || sqlStmtBase;
              EXECUTE IMMEDIATE sqlStmt INTO modelID ;
              choicekid := TRUE; seqKid := FALSE; allKid := FALSE;
            ELSE
              sqlStmt := 'select count(*)   from xdb.xdb$sequence_model sm, ' || sqlStmtBase;
              EXECUTE IMMEDIATE sqlStmt INTO counter;
              IF (counter <> 0) THEN
                 sqlStmt := 'select sm.sys_nc_oid$  from xdb.xdb$sequence_model sm, ' || sqlStmtBase;
                 EXECUTE IMMEDIATE sqlStmt INTO modelID ;
                 choicekid := FALSE; seqKid := TRUE; allKid := FALSE;
              ELSE
                 sqlStmt := 'select count(*)  from xdb.xdb$all_model sm, ' || sqlStmtBase;
                 EXECUTE IMMEDIATE sqlStmt INTO counter ;
                 IF (counter <> 0) THEN
                    sqlStmt := 'select sm.sys_nc_oid$   from xdb.xdb$all_model sm, ' || sqlStmtBase;
                    EXECUTE IMMEDIATE sqlStmt INTO modelID;
                    choicekid := FALSE; seqKid := FALSE; allKid := TRUE;
                 ELSE -- group
                    IF (seqKid = TRUE) THEN kidClause := 'sequence_kid';
                    ELSIF (choiceKid = TRUE) THEN kidClause := 'choice_kid';
                    ELSE kidClause := 'all_kid';
                    END IF;
                    sqlStmtBase := '  from xdb.xdb$group_def sm where sys_op_r2o(sm.xmldata. ' || kidClause || ') =';
                    sqlStmtBase := sqlStmtBase || Dbms_Assert.Enquote_Literal(modelID);
                    sqlStmt := 'select count(*) ' || sqlStmtBase;
                    EXECUTE IMMEDIATE sqlStmt INTO counter ;
                    IF (counter <> 0) THEN
                       sqlStmt := 'select sm.sys_nc_oid$ ' || sqlStmtBase;
                       EXECUTE IMMEDIATE sqlStmt INTO modelID;
                       RETURN getParentIDFromGroupID(modelID);
                    ELSE
                       RETURN getParentIDFromModelID(modelID);
                    END IF;
                 END IF;
              END IF;
           END IF;
       END LOOP;

    RETURN NULL;
    EXCEPTION
    WHEN OTHERS THEN
       RETURN NULL;
END;

  Function sizeArray ( elementID IN varchar2 )
       RETURN NUMBER
  IS
   p parentidarray;
  BEGIN
    p := PrvtParentChild.getparentID(elementID);
    IF (p IS NULL) THEN
       RETURN 0;
    ELSE
       RETURN p.count;
    END IF;
  END;
END;
/

