create type aq$_jms_map_message         authid current_user as object
(
  header     aq$_jms_header,
  bytes_len  int,
  bytes_raw  raw(2000),
  bytes_lob  blob,
  STATIC FUNCTION construct RETURN aq$_jms_map_message,
  STATIC FUNCTION get_exception
  RETURN AQ$_JMS_EXCEPTION,
  STATIC PROCEDURE clean_all,
  MEMBER FUNCTION prepare (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,
  MEMBER FUNCTION clear_body (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,
  MEMBER PROCEDURE flush (id IN PLS_INTEGER),
  MEMBER PROCEDURE clean (id IN PLS_INTEGER),
  MEMBER FUNCTION get_size (id IN PLS_INTEGER)
  RETURN PLS_INTEGER,
  MEMBER FUNCTION get_names (id IN PLS_INTEGER)
  RETURN AQ$_JMS_NAMEARRAY,
  MEMBER FUNCTION get_names (
         id       IN        PLS_INTEGER,
         names    OUT       AQ$_JMS_NAMEARRAY,
         offset   IN        PLS_INTEGER,
         length   IN        PLS_INTEGER )
  RETURN PLS_INTEGER,
  MEMBER FUNCTION item_exists (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN BOOLEAN,
  MEMBER PROCEDURE get_object (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY AQ$_JMS_VALUE),
  MEMBER FUNCTION get_boolean (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN BOOLEAN,
  MEMBER FUNCTION get_byte (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,
  MEMBER PROCEDURE get_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY BLOB),
  MEMBER FUNCTION get_char (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN CHAR,
  MEMBER FUNCTION get_double (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN DOUBLE PRECISION,
  MEMBER FUNCTION get_float (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN FLOAT,
  MEMBER FUNCTION get_int (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,
  MEMBER FUNCTION get_long (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN NUMBER,
  MEMBER FUNCTION get_short (id IN PLS_INTEGER, name IN VARCHAR2)
  RETURN PLS_INTEGER,
  MEMBER PROCEDURE get_string (id IN PLS_INTEGER, name IN VARCHAR2, value OUT NOCOPY CLOB),
  MEMBER PROCEDURE set_boolean (id IN PLS_INTEGER, name IN VARCHAR2, value IN BOOLEAN),
  MEMBER PROCEDURE set_byte (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),
  MEMBER PROCEDURE set_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value IN RAW),
  MEMBER PROCEDURE set_bytes (id IN PLS_INTEGER, name IN VARCHAR2, value IN BLOB),
  MEMBER PROCEDURE set_bytes (
         id        IN      PLS_INTEGER,
         name      IN      VARCHAR2,
         value     IN      RAW,
	 offset    IN      PLS_INTEGER,
	 length    IN      PLS_INTEGER
  ),
  MEMBER PROCEDURE set_bytes (
         id        IN      PLS_INTEGER,
         name      IN      VARCHAR2,
         value     IN      BLOB,
         offset    IN      PLS_INTEGER,
         length    IN      PLS_INTEGER
  ),
  MEMBER PROCEDURE set_char (id IN PLS_INTEGER, name IN VARCHAR2, value IN CHAR),
  MEMBER PROCEDURE set_double (id IN PLS_INTEGER, name IN VARCHAR2, value IN DOUBLE PRECISION),
  MEMBER PROCEDURE set_float (id IN PLS_INTEGER, name IN VARCHAR2, value IN FLOAT),
  MEMBER PROCEDURE set_int (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),
  MEMBER PROCEDURE set_long (id IN PLS_INTEGER, name IN VARCHAR2, value IN NUMBER),
  MEMBER PROCEDURE set_short (id IN PLS_INTEGER, name IN VARCHAR2, value IN PLS_INTEGER),
  MEMBER PROCEDURE set_string (id IN PLS_INTEGER, name IN VARCHAR2, value IN VARCHAR2),
  MEMBER PROCEDURE set_string (id IN PLS_INTEGER, name IN VARCHAR2, value IN CLOB),
  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),
  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),
  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),
  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),
  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),
  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),
  MEMBER PROCEDURE clear_properties ,
  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),
  MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),
  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),
  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),
  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),
  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),
  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,
  MEMBER FUNCTION get_type RETURN VARCHAR,
  MEMBER FUNCTION get_userid RETURN VARCHAR,
  MEMBER FUNCTION get_appid RETURN VARCHAR,
  MEMBER FUNCTION get_groupid RETURN VARCHAR,
  MEMBER FUNCTION get_groupseq RETURN int,
  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,
  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,
  MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,
  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,
  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,
  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR
)
/

