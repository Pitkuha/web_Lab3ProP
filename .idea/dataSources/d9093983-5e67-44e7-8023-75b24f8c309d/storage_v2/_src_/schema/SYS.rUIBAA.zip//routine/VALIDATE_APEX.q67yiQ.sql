create procedure validate_apex
as
    type obj_arr         is table of varchar2(30) index by binary_integer;
    g_objects            obj_arr;
    l_type#              binary_integer;
    l_owner#             binary_integer;
    l_ltype              varchar2(30) := 'FIRST';
    l_status             binary_integer;
    l_compile_sql        varchar2(2000);
    l_obj_found          boolean;
    l_start_time         date;
    l_user               varchar2(255);
    --
    l_obj_count          pls_integer := 0;
    l_obj_compile_count  pls_integer := 0;
    l_package_count      pls_integer := 0;
    l_table_count        pls_integer := 0;
    l_function_count     pls_integer := 0;
    l_package_body_count pls_integer := 0;
    l_sequence_count     pls_integer := 0;
    l_trigger_count      pls_integer := 0;
    l_index_count        pls_integer := 0;
    l_view_count         pls_integer := 0;
    l_library_count      pls_integer := 0;
    l_type_count         pls_integer := 0;
    l_type_body_count    pls_integer := 0;
    l_operator_count     pls_integer := 0;
    l_indextype_count    pls_integer := 0;
    l_procedure_count    pls_integer := 0;
    --
    l_invalid_object_cnt pls_integer := 0;
    l_exists_failure_cnt pls_integer := 0;

    INVALID_OBJECT_NAME EXCEPTION;
    PRAGMA EXCEPTION_INIT(INVALID_OBJECT_NAME, -44002);

    procedure log_action (
       p_message in varchar2 default null)
    is
    begin
       for c1 in (select sysdate d from dual) loop
           dbms_output.put_line(
                '...'||
                p_message||' '||
                to_char(c1.d,'HH24:MI:SS')
                );
       end loop;
    end log_action;
begin
  -------------------
  -- init logging env
  --

  select sysdate, user into l_start_time, l_user from dual;
  select user# into l_owner# from sys.user$ where name = 'APEX_040200';
  log_action('Database user "'||l_user||'", database schema "APEX_040200", user# "'||l_owner#||'"');

  --------------------------------------------
  -- Loop over all objects owned by APEX owner
  --
  for c1 in (select object_name, object_type
               from all_objects
              where owner        = 'APEX_040200' and
                    object_type not in 'SYNONYM' and
                    object_type not like 'LOB%'
              order by object_type, object_name)
  loop
    l_obj_count := l_obj_count + 1;

    ------------------------
    -- determine object type
    --
    if (c1.object_type != l_ltype) then
      select decode(c1.object_type, 'INDEX',         1,
                                    'TABLE',         2,
                                    'VIEW',          4,
                                    'SEQUENCE',      6,
                                    'PROCEDURE',     7,
                                    'FUNCTION',      8,
                                    'PACKAGE',       9,
                                    'PACKAGE BODY', 11,
                                    'TRIGGER',      12,
                                    'TYPE',         13,
                                    'TYPE BODY',    14,
                                    'LIBRARY',      22,
                                    'INDEXTYPE',    32,
                                    'OPERATOR',     33,
                                    0)
        into l_type#
        from dual;
      l_ltype := c1.object_type;
    end if;

    if c1.object_type = 'TABLE'          then l_table_count := l_table_count + 1; end if;
    if c1.object_type = 'FUNCTION'       then l_function_count := l_function_count + 1; end if;
    if c1.object_type = 'PACKAGE'        then l_package_count := l_package_count + 1; end if;
    if c1.object_type = 'PACKAGE BODY'   then l_package_body_count := l_package_body_count + 1; end if;
    if c1.object_type = 'SEQUENCE'       then l_sequence_count := l_sequence_count + 1; end if;
    if c1.object_type = 'TRIGGER'        then l_trigger_count := l_trigger_count + 1; end if;
    if c1.object_type = 'INDEX'          then l_index_count := l_index_count + 1; end if;
    if c1.object_type = 'VIEW'           then l_view_count := l_view_count + 1; end if;
    if c1.object_type = 'TYPE'           then l_type_count := l_type_count + 1; end if;
    if c1.object_type = 'TYPE BODY'      then l_type_body_count := l_type_body_count + 1; end if;
    if c1.object_type = 'LIBRARY'        then l_library_count := l_library_count + 1; end if;
    if c1.object_type = 'OPERATOR'       then l_operator_count := l_operator_count + 1; end if;
    if c1.object_type = 'INDEXTYPE'      then l_indextype_count := l_indextype_count + 1; end if;
    if c1.object_type = 'PROCEDURE'      then l_procedure_count := l_procedure_count + 1; end if;

    --------------------------
    -- determine object status
    --
    l_status := -1;
    for c2 in (select status from sys.obj$
                where owner# = l_owner#
                  and name = c1.object_name
                  and type# = l_type# )
    loop
      l_status := c2.status;
    end loop;

    if (l_status != 1) then
      -----------------------------------
      -- Compile objects that are invalid
      --
      l_compile_sql :=
        case c1.object_type
          when 'VIEW' then
            'alter view APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'PROCEDURE' then
            'alter procedure APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'FUNCTION' then
            'alter function APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'PACKAGE' then
            'alter package APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'PACKAGE BODY' then
            'alter package APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile body'
          when 'TYPE' then
            'alter type APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'TYPE BODY' then
            'alter type APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile body'
          when 'INDEXTYPE' then
            'alter indextype APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'OPERATOR' then
            'alter operator APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          when 'TRIGGER' then
            'alter trigger APEX_040200.' || dbms_assert.enquote_name(c1.object_name, FALSE) || ' compile'
          else null
        end;

      if l_compile_sql is not null and instr(l_compile_sql,'WWV_FLOW_CUSTOM_AUTH_SSO') = 0 then
        begin
          execute immediate l_compile_sql;
          l_obj_compile_count := l_obj_compile_count + 1;
          log_action('"'||l_compile_sql||'"');
        exception
          when others then
            log_action('FAILED CHECK FOR "'||c1.object_type||'" "'||c1.object_name||'" '||sqlerrm);
            log_action('command: "'||l_compile_sql||'"');
            l_invalid_object_cnt := l_invalid_object_cnt + 1;
            if l_invalid_object_cnt = 1 then
               dbms_registry.invalid('APEX');
               log_action('DBMS registry set to invalid for APEX');
            end if;
            --goto endfunc;
        end;
      end if;

    end if;


  end loop;
    log_action('Compiled '||l_obj_compile_count||' out of '||l_obj_count||' objects considered, '||l_invalid_object_cnt||' failed compilation');

    dbms_output.put_line ('...'||l_package_count||' packages');
    dbms_output.put_line ('...'||l_package_body_count||' package bodies');
    dbms_output.put_line ('...'||l_table_count||' tables');
    dbms_output.put_line ('...'||l_function_count||' functions');
    dbms_output.put_line ('...'||l_procedure_count||' procedures');
    dbms_output.put_line ('...'||l_sequence_count||' sequences');
    dbms_output.put_line ('...'||l_trigger_count||' triggers');
    dbms_output.put_line ('...'||l_index_count||' indexes');
    dbms_output.put_line ('...'||l_view_count||' views');
    dbms_output.put_line ('...'||l_library_count||' libraries');
    dbms_output.put_line ('...'||l_type_count||' types');
    dbms_output.put_line ('...'||l_type_body_count||' type bodies');
    dbms_output.put_line ('...'||l_operator_count||' operators');
    dbms_output.put_line ('...'||l_indextype_count||' index types');

    -----------------------------------
    -- populate array of APEX g_objects
    --
    log_action('Begin key object existence check');
    g_objects(g_objects.count+1) := 'WWV_FLOW_COLLECTIONS$';
    g_objects(g_objects.count+1) := 'WWV_FLOW_COMPANIES';
    g_objects(g_objects.count+1) := 'WWV_FLOW_FND_USER';
    g_objects(g_objects.count+1) := 'WWV_FLOW_ITEMS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_LISTS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_MAIL_QUEUE';
    g_objects(g_objects.count+1) := 'WWV_FLOW_MESSAGES$';
    g_objects(g_objects.count+1) := 'WWV_FLOW_PAGE_PLUGS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_STEP_ITEMS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_STEP_PROCESSING';
    g_objects(g_objects.count+1) := 'WWV_FLOW_STEP_VALIDATIONS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_STEPS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_SW_STMTS';
    g_objects(g_objects.count+1) := 'WWV_FLOWS';
    g_objects(g_objects.count+1) := 'WWV_FLOW_DML';
    g_objects(g_objects.count+1) := 'WWV_FLOW_ITEM';
    g_objects(g_objects.count+1) := 'WWV_FLOW_LANG';
    g_objects(g_objects.count+1) := 'WWV_FLOW_LOG';
    g_objects(g_objects.count+1) := 'WWV_FLOW_MAIL';
    g_objects(g_objects.count+1) := 'WWV_FLOW_SVG';
    g_objects(g_objects.count+1) := 'WWV_FLOW_SW_PARSER';
    g_objects(g_objects.count+1) := 'WWV_FLOW_SW_UTIL';
    g_objects(g_objects.count+1) := 'WWV_FLOW_UTILITIES';
    g_objects(g_objects.count+1) := 'F';
    g_objects(g_objects.count+1) := 'P';
    g_objects(g_objects.count+1) := 'Z';
    g_objects(g_objects.count+1) := 'V';
    --------------------------------------
    -- Check for existence of core objects
    --
    for j in 1.. g_objects.count loop

        l_obj_found := false;
        for c1 in (select null
                     from all_objects
                    where owner = 'APEX_040200'
                      and object_name = g_objects(j) ) loop

            l_obj_found := true;
        end loop;

        if not l_obj_found then
            dbms_output.put_line('FAILED Existence check for '||g_objects(j));
            l_exists_failure_cnt := l_exists_failure_cnt + 1;
            if l_exists_failure_cnt = 1 then
                dbms_registry.invalid('APEX');
                log_action('DBMS registry set to invalid for APEX');
            end if;
        end if;
    end loop;

    l_obj_found := false;
    for c1 in (select null
                 from all_objects
                where owner = 'SYS'
                  and object_name = 'WWV_DBMS_SQL' ) loop

        l_obj_found := true;

    end loop;

    if not l_obj_found then
        log_action('FAILED Existence check for WWV_DBMS_SQL');
        l_exists_failure_cnt := l_exists_failure_cnt + 1;
        if l_exists_failure_cnt = 1 then
            dbms_registry.invalid('APEX');
            log_action('DBMS registry set to invalid for APEX');
        end if;
    end if;

  log_action('Completed key object existence check');
  if l_exists_failure_cnt = 0 and l_invalid_object_cnt = 0 then
     log_action('Setting DBMS Registry');
     dbms_registry.valid('APEX');
     log_action('Setting DBMS Registry Complete');
  end if;
<<endfunc>>
  null;
  log_action('Exiting validate');
exception
  when others then
    dbms_registry.invalid('APEX');
    log_action('Error in validation: '||sqlerrm);
end validate_apex;
/

