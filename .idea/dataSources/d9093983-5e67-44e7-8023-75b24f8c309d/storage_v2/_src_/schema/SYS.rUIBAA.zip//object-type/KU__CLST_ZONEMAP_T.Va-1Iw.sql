create type ku$_clst_zonemap_t as object
(
  obj_num       number,                       /* object number of base table */
  zmowner       varchar2(30),                               /* zonemap owner */
  zmname        varchar2(30)                                 /* zonemap name */
)
/

