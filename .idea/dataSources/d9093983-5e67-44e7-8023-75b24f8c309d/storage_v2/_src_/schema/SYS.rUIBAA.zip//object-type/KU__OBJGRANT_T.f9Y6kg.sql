create type ku$_objgrant_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                 /* obj# of base obj. */
  base_obj      ku$_schemaobj_t,                           /* base obj. info */
  long_name     varchar2(4000),
  grantor       varchar2(30),
  grantee       varchar2(30),
  privname      varchar2(40),
  sequence      number,                        /* Unique seq# for this grant */
  wgo           number,                             /* with grant option = 1 */
                                                /* with hierarchy option = 2 */
  colname       varchar2(30))          /* column name if col grant else null */

