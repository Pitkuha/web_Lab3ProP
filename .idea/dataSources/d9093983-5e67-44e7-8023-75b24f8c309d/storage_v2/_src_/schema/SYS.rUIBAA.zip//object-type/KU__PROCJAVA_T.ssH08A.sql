create type ku$_procjava_t as object
( obj_num       number,                 /* spec/body object number */
  procedure_num number,                  /* procedure# or position */
  ownername     varchar2(30),            /* class owner name */
  ownerlength   number,              /* length of class owner name */
  usersignature varchar2(4000),              /* User signature for java */
  usersiglen    number,                /* Length of user signature for java */
  classname     varchar2(4000),           /* method class name */
  classlength   number,             /* length of method class name */
  methodname    varchar2(4000),            /* java method name */
  methodlength  number,              /* length of java method name */
  flags         varchar2(4000),              /* internal flags */
  flagslength   number,                /* length of internal flags */
  cookiesize    number)                                      /* cookie size */

