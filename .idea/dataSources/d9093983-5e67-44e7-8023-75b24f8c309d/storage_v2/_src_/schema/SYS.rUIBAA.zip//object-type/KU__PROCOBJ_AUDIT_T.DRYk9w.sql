create type ku$_procobj_audit_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                              /* schema object number */
  base_obj      ku$_schemaobj_t,                            /* schema object */
  class         number,                      /* 1: sys, 2:schema, 3:instance */
  prepost       number,                          /* 0:praction, 1:postaction */
  type_num      number,                                           /* type id */
  level_num     number,                                             /* level */
  package       varchar2(30),                          /* procedural package */
  pkg_schema    varchar2(30),                              /* package schema */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
/

