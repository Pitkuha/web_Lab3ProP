create PROCEDURE dbms_feature_unified_audit
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   feature_usage         VARCHAR2(1000);
   uniaud_linkon         NUMBER;
   unified_policies      NUMBER;
   unified_policies_enb  NUMBER;
   unified_policies_cond NUMBER;
   unified_policies_dv   NUMBER;
   unified_policies_ols  NUMBER;
   unified_policies_xs   NUMBER;
   unified_policies_dp   NUMBER;
   unified_contexts      NUMBER;
BEGIN

  -- Initialize
  feature_boolean       := 0;
  aux_count             := 0;
  feature_info          := NULL;
  unified_policies      := 0;
  unified_policies_enb  := 0;
  unified_policies_cond := 0;
  unified_policies_dv   := 0;
  unified_policies_ols  := 0;
  unified_policies_xs   := 0;
  unified_policies_dp   := 0;
  unified_contexts      := 0;

  -- Check if 'uniaud_on' is linked
  select count(*) into uniaud_linkon from v$option
    where parameter like '%Unified Auditing%' and value = 'TRUE';

  -- Get number of Unified Audit policies created in the database
  select count(*) into unified_policies from aud_policy$;

  -- Get number of Unified Audit policies enabled in the database
  select count(distinct policy#) into unified_policies_enb from audit_ng$;

  -- Get number of Unified Audit policies with condition
  select count(*) into unified_policies_cond from aud_policy$
    where condition is NOT NULL;

  -- Get number of Unified Audit policies for each componenet
  FOR item IN (SELECT audit_option_type, count(distinct policy_name) pol_cnt
               FROM AUDIT_UNIFIED_POLICIES group by audit_option_type)
  LOOP
    IF (item.audit_option_type LIKE 'DV%') THEN
      unified_policies_dv := item.pol_cnt;
    ELSIF (item.audit_option_type LIKE 'OLS%') THEN
      unified_policies_ols := item.pol_cnt;
    ELSIF (item.audit_option_type LIKE 'XS%') THEN
      unified_policies_xs := item.pol_cnt;
    ELSIF (item.audit_option_type LIKE 'DATAPUMP%') THEN
      unified_policies_dp := item.pol_cnt;
    END IF;
  END LOOP;

  -- Get number of contexts enabled for audit
  select count(*) into unified_contexts from aud_context$;

  -- If 'uniaud_on' is linked, then Unified audit feature is enabled.
  -- Else if atleast a single Unified audit policy is enabled,
  --   then Unified audit feature is enabled.
  if ((uniaud_linkon > 0) OR (unified_policies_enb > 0)) then
    feature_boolean := 1;
  end if;

  feature_usage := 'Number of Unified Audit policies=' ||
                   to_char(unified_policies) || '; ' ||
                   'Number of Enabled Unified Audit policies=' ||
                   to_char(unified_policies_enb) || '; ' ||
                   'Number of Unified Audit policies with condition=' ||
                   to_char(unified_policies_cond) || '; ' ||
                   'Number of Unified Audit policies on DV=' ||
                   to_char(unified_policies_dv) || '; ' ||
                   'Number of Unified Audit policies on OLS=' ||
                   to_char(unified_policies_ols) || '; ' ||
                   'Number of Unified Audit policies on XS=' ||
                   to_char(unified_policies_xs) || '; ' ||
                   'Number of Unified Audit policies on DATAPUMP=' ||
                   to_char(unified_policies_dp) || '; ' ||
                   'Number of Enabled Unified Audit Contexts=' ||
                   to_char(unified_contexts);
  feature_info := to_clob(feature_usage);

END dbms_feature_unified_audit;
/

