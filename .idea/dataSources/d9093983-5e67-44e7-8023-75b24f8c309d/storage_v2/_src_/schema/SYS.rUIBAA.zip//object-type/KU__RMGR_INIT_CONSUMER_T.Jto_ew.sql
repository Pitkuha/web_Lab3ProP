create type ku$_rmgr_init_consumer_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_num      number,
  grantee       varchar2(30),
  granted_group varchar2(30), /* consumer groups to which the user can switch */
  grant_option  number,                 /* mod(a.option$) =1 yes, others no */
                       /* whether the user can grant the privilege to others */
  defschclass   VARCHAR2(30)                                /* initial group */
)
/

