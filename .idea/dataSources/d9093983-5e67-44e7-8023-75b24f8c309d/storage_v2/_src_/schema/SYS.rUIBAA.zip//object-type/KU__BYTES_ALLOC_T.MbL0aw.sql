create type ku$_bytes_alloc_t as object
(
  file_num      number,                        /* segment header file number */
  block_num     number,                       /* segment header block number */
  ts_num        number,                       /* tablespace for this segment */
  bytes_alloc   number                     /* total number of bytes allocated */
)
/

