create type ku$_procobj_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                              /* schema object number */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  class         number,                         /* 1:sys,2:schema,3:instance */
  prepost       number,                         /* 0:preaction, 1:postaction */
  type_num      number,                                           /* type id */
  level_num     number,                                             /* level */
  package       varchar2(128),                         /* procedural package */
  pkg_schema    varchar2(128),                             /* package schema */
  plsql         ku$_procobj_lines      /* PL/SQL code for procedural objects */
)
/

