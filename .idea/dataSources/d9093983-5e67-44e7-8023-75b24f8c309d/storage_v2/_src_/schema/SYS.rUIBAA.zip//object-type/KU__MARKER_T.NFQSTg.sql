create type ku$_marker_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  marker        number                                        /* marker type */
)
/

