create PROCEDURE dbms_pdb_num
     ( feature_boolean  OUT NUMBER,
       aux_count        OUT NUMBER,
       feature_info     OUT CLOB)
AS
begin
  feature_boolean := 0;
  aux_count := 0;
  feature_info := NULL;

  select count(*) into feature_boolean from v$database where cdb = 'YES';
  if (feature_boolean = 1) then
    select count(*) into aux_count from v$pdbs where con_id > 2;
  end if;

end dbms_pdb_num;
/

