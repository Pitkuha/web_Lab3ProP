create type ku$_mv_deptbl_objnum_t as object
(
  obj_num       number                                             /* obj# */
)
/

