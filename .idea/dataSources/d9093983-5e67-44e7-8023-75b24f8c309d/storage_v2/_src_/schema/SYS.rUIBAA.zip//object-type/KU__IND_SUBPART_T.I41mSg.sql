create type ku$_ind_subpart_t as object
(
  obj_num       number,                              /* obj# of subpartition */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  ts_name       varchar2(30),                             /* tablespace name */
  blocksize     number,                            /* size of block in bytes */
  storage       ku$_storage_t,                                    /* storage */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  dataobj_num   number,                          /* data layer object number */
  pobj_num      number,                              /* parent object number */
  subpart_num   number,                               /* subpartition number */
  tab_subpart_name varchar2(30),                  /* table subpartition name */
  flags         number,                                             /* flags */
  pct_free      number,          /* minimum free space percentage in a block */
  initrans      number,                    /* initial number of transactions */
  maxtrans      number,                    /* maximum number of transactions */
  analyzetime   varchar2(19),                /* timestamp when last analyzed */
  samplesize    number,                          /* samplesize for histogram */
  rowcnt        number,                                    /* number of rows */
  blevel        number,                                      /* B-tree level */
  leafcnt       number,                             /* number of leaf blocks */
  distkey       number,                           /* number of distinct keys */
  lblkkey       number,             /* average number of leaf blocks per key */
  dblkkey       number,             /* average number of data blocks per key */
  clufac        number,                                 /* clustering factor */
  spare1        number,
  spare2        number,
  spare3        number
)
/

