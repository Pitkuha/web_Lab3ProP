create type ku$_library_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                             /* library object number */
  schema_obj    ku$_schemaobj_t,                    /* library schema object */
  filespec      varchar2(2000),                                  /* filename */
  lib_audit     varchar2(2000),
  property      number,
  agent         varchar2(128),                  /* network agent for library */
  directory     varchar2(128),          /* directory object for library file */
  filename      varchar2(2000),                   /* filename of the library */
  credential    ku$_credential_t
)
/

