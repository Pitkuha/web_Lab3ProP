create type ku$_proxy_role_item_t as object
(
  role_id       number,                                           /* role id */
  client        varchar2(30),                                 /* client name */
  proxy         varchar2(30),                                  /* proxy name */
  role          varchar2(30)                                 /* role context */
)
/

