create PROCEDURE dbms_feature_qosm
      (is_used OUT number, aux_count OUT number, feature_info OUT clob)
AS
  measure_only     number;
BEGIN
  -- initialize
  feature_info := NULL;
  aux_count := NULL;

  -- get number of performance classes

  select count(*) into is_used from x$kywmpctab
    where kywmpctabsp not like ':%';

  -- if QOSM is used
  if (is_used >= 1) then

    -- number of Performance Classes
    aux_count := is_used;

    -- check if QoSM is in measure only mode
    select count(kywmpctabmonly) into measure_only from x$kywmpctab
      where kywmpctabsp not like ':%' and kywmpctabmonly = 0;
    if (measure_only = 0) then
      feature_info := to_clob('QoSM is in measure only mode');
    else
      feature_info := to_clob('QoSM is in management mode');
    end if;

  end if;
END;
/

