create type ku$_resocost_item_t as object
(
  resource_id       number,                                   /* resource id */
  resource_name     varchar2(30),                                /* resource */
  resource_type     number,                                          /* type */
  unit_cost         number                                      /* unit cost */
)
/

