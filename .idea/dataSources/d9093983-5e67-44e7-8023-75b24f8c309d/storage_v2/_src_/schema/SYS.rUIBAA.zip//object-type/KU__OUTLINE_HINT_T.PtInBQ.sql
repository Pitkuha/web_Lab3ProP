create type ku$_outline_hint_t as object
( name              varchar2(30),                           /* outline name */
  hint              number,               /* which hint for a given outline */
  category          varchar2(30),               /* collection/grouping name */
  hint_type         number,                                 /* type of hint */
  hint_text         varchar2(512),             /* hint specific information */
  stage             number,            /* stage of hint generation/applic'n */
  node              number,                                  /* QBC node id */
  table_name        varchar2(30),                       /* for ORDERED hint */
  table_tin         number,                        /* table instance number */
  table_pos         number,                             /* for ORDERED hint */
  ref_id            number,        /* node id that this hint is referencing */
  user_table_name   varchar2(30),  /* table name to which this hint applies */
  cost              double precision,    /* optimizer estimated cost of the
                                                           hinted operation */
  cardinality       double precision,    /* optimizer estimated cardinality
                                                    of the hinted operation */
  bytes             double precision,     /* optimizer estimated byte count
                                                    of the hinted operation */
  hint_textoff      number,             /* offset into the SQL statement to
                                                    which this hint applies */
  hint_textlen      number,     /* length of SQL to which this hint applies */
  join_pred         varchar2(2000)      /* join predicate (applies only for
                                                         join method hints) */
)
/

