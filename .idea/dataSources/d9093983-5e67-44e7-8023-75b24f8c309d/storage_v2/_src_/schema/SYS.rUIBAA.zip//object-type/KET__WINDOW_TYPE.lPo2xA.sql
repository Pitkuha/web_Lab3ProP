create TYPE ket$_window_type IS OBJECT (
   window_name   VARCHAR2(30),
   start_time    TIMESTAMP WITH TIME ZONE,
   duration      INTERVAL DAY TO SECOND)
/

