create type ku$_cube_tab_t as object
(
  obj_num       number,                             /* Parent table object # */
  awname        varchar2(100),                         /* Underlying AW name */
  flags         number,                                             /* Flags */
  dims          ku$_cube_dim_list_t,                           /* Dimensions */
  facts         ku$_cube_fact_list_t,                            /* Measures */
  cgid          ku$_cube_fact_list_t                             /* Cube GID */
)
/

