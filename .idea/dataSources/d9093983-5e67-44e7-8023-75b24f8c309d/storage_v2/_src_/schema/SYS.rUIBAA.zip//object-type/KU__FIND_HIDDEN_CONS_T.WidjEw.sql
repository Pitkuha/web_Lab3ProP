create type ku$_find_hidden_cons_t as object
(
  con_num       number,                                 /* constraint number */
  constr_name   varchar2(30),                             /* constraint name */
  owner_name    varchar2(30),                           /* object owner name */
  table_name    varchar2(30),                 /* object ([nested]table) name */
  intcol_num    number                   /* OID/SETID internal column number */
)
/

