create type ku$_comment_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                                     /* object number */
  base_obj      ku$_schemaobj_t,                       /* base schema object */
  property      number,                                  /* table properties */
  colno         number,                                         /* column id */
  colname       varchar2(30),                                 /* column name */
  cmnt          clob                                         /* comment text */
)
/

