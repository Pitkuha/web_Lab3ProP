create TYPE     ku$_parsed_item AS OBJECT
        (       item            VARCHAR2(30),   -- item to be parsed
                value           VARCHAR2(4000), -- item's value
                object_row      NUMBER          -- object row of item
        )
/

