create TYPE hs_sample_obj authid current_user AS OBJECT
 (low_value varchar2(4000),
 high_value varchar2(4000),
 position  number,
 data_type varchar2(106));
/

