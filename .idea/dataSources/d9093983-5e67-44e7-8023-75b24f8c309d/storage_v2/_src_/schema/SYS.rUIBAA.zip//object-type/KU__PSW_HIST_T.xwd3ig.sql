create type ku$_psw_hist_t as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  user_id       number,
  name          varchar2(30),
  hist_list     ku$_psw_hist_list_t                     /* password history */
)
/

