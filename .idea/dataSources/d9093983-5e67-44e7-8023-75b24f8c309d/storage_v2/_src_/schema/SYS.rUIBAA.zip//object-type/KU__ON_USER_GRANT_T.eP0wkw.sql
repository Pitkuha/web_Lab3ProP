create type ku$_on_user_grant_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  user_name      varchar2(30),
  grantor       varchar2(30),
  grantee       varchar2(30),
  sequence      number)                        /* Unique seq# for this grant */

