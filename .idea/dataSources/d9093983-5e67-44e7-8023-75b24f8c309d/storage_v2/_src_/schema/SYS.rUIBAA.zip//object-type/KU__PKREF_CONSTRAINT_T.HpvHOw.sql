create type ku$_pkref_constraint_t as object
(
  obj_num       number,                      /* object number of base object */
  col_num       number,                                     /* column number */
  intcol_num    number,                            /* internal column number */
  reftyp        number,                                     /* REF type flag */
                                                     /* 0x01 = REF is scoped */
                                             /* 0x02 = REF stored with rowid */
                                             /* 0x04 = Primary key based ref */
                            /* 0x08 = Unscoped primary key based ref allowed */
        /* 0x10 (16) = ref generated for xdb:SQLInline="false" (bug 6676049) */
  property      number,                     /* column properties (bit flags) */
  name          varchar2(30),                              /* name of column */
  attrname      varchar2(4000),/* name of type attr. column: null if != type */
  schema_obj    ku$_schemaobj_t,                         /* referenced table */
  foreignkey    number,               /* 1= scoped REF is also a foreign key */
  pk_col_list   ku$_simple_col_list_t   /* any pkREF refd. pkey constr. cols */
)
/

