create type dm_model_global_detail
                                       as object
  (global_detail_name    VARCHAR2(30)
  ,global_detail_value   number)
/

