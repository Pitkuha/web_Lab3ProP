create TYPE ku$_ObjNumNam as
 object (obj_num NUMBER,name VARCHAR2(30));
/

