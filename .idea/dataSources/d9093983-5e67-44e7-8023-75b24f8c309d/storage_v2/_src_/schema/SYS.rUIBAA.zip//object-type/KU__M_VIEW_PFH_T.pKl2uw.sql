create type ku$_m_view_pfh_t as object
(
  vers_major        char(1),                          /* UDT major version # */
  vers_minor        char(1),                          /* UDT minor version # */
  sowner            varchar2(30),                       /* Owner of snapshot */
  vname             varchar2(30),                        /* name of snapshot */
  mview             ku$_m_view_t,
  mview_tab         ku$_pfhtable_t,
  mview_idx_list    ku$_index_list_t
)
/

