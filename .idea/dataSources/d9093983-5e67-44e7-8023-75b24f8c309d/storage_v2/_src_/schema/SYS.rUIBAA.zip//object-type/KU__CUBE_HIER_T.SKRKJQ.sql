create type ku$_cube_hier_t as object
(
  obj_num  number,                                  /* Parent table object # */
  rel      varchar2(100),                              /* Mapped AW relation */
  qdr      varchar2(100),                         /* QDRing dimension object */
  qdrval   varchar2(100),                                     /* QDRed value */
  levels   ku$_cube_fact_list_t,                      /* Levels in hierarchy */
  inhier   ku$_cube_fact_list_t,                   /* Mapped AW IN Hierarchy */
  flags    number                                                   /* Flags */
)
/

