create PROCEDURE reset_undo_stat
IS
  resetsql varchar2(1024);
  val     number;
  cid     number;
  rows    integer;
BEGIN
  val := 2;
  resetsql := 'alter system set "_undo_debug_usage" = ' || val;
  cid := dbms_sql.open_cursor;
  dbms_sql.parse(cid, resetsql, dbms_sql.native);
  rows := dbms_sql.execute(cid);
  dbms_sql.close_cursor(cid);
END reset_undo_stat;
/

