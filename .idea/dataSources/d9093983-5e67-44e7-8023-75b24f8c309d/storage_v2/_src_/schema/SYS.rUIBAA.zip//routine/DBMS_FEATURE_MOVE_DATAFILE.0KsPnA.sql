create procedure DBMS_FEATURE_MOVE_DATAFILE
    (feature_boolean  OUT  NUMBER,
     aux_count        OUT  NUMBER,
     feature_info     OUT  CLOB)
AS
    feature_usage      varchar2(1000);
    use_omd_primary    varchar2(5);
    use_pri            number;

begin
    -- initialize
    feature_boolean := 0;
    aux_count := 0;
    use_omd_primary := 'FALSE';

    execute immediate 'select DI2MVUSE_PRI from X$KCCDI2'
      into use_pri;
    if (use_pri > 0) then
      use_omd_primary := 'TRUE';
      feature_boolean := 1;
    end if;

    if (feature_boolean = 1) then
        feature_usage :=
                'Online Move Datafile on primary used: '
             || upper(use_omd_primary)
        ;
        feature_info := to_clob(feature_usage);
    else
        feature_info := to_clob('Online Move Datafile usage not detected');
    end if;
end;
/

