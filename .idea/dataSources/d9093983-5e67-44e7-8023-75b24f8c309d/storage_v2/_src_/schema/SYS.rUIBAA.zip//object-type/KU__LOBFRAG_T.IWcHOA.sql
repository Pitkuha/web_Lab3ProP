create type ku$_lobfrag_t as object
(
  obj_num       number,                            /* fragment object number */
  parent_obj_num number,                             /* parent object number */
  part_obj_num  number,                           /* partition object number */
  base_obj_num  number,                               /* obj# of base table */
  intcol_num    number,                            /* internal column number */
  part_num      number,                                  /* partition number */
  schema_obj    ku$_schemaobj_t,                        /* LOB schema object */
  storage       ku$_storage_t,                          /* LOB storage       */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  ts_name       varchar2(30),                             /* tablespace name */
  blocksize     number,                            /* size of block in bytes */
  ind_num       number,                                 /* LOB index obj #   */
  lobindex      ku$_lobfragindex_t,                      /* LOB index object */
  chunk         number,                    /* oracle blocks in one lob chunk */
  pctversion    number,                                      /* version pool */
  flags         number,                                             /* flags */
                                                 /* 0x0001 = NOCACHE LOGGING */
                                               /* 0x0002 = NOCACHE NOLOGGING */
                                             /* 0x0008 = CACHE READS LOGGING */
                                           /* 0x0010 = CACHE READS NOLOGGING */
  property      number,                    /* 0x00 = user defined lob column */
                                    /* 0x01 = kernel column(s) stored as lob */
                                     /* 0x02 = user lob column with row data */
                                            /* 0x04 = partitioned LOB column */
                                   /* 0x0008 = LOB In Global Temporary Table */
                                          /* 0x0010 = Session-specific table */
  spare1        number,
  spare2        number,
  spare3        number
)
/

