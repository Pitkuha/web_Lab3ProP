create type ku$_histgrm_t as object
(
  obj_num           number,             -- histogram object number
  intcol_num        number,             -- internal object number
  bucket            number,             -- bucket information
  endpoint          number,             -- endpoint value
  epvalue           VARCHAR2(4000),     -- ep value
  epvalue_raw       RAW(1000),          -- ep value in raw type (12g)
  ep_repeat_count   NUMBER,             -- ep repeat count (12g)
  spare1            number              -- sample number of distinct values
)
/

