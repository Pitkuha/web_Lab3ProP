create TYPE       "extra_attribute_values46_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","extra_attribute_value" "extra_attribute_valu47_COLL")FINAL INSTANTIABLE
/

