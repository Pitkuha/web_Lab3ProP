create type ku$_plugts_tablespace_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  ts_num        number,                                 /* tablespace number */
  bitmapped     number,      /* If not bitmapped, 0 else unit size in blocks */
  flags         number,                                     /* various flags */
                                     /* 0x01 = system managed allocation     */
                                     /* 0x02 = uniform allocation            */
                                /* if above 2 bits not set then user managed */
                                     /* 0x04 = migrated tablespace           */
                                     /* 0x08 = tablespace being migrated     */
                                     /* 0x10 = undo tablespace               */
                                     /* 0x20 = auto segment space management */
                       /* if above bit not set then freelist segment managed */
                                     /* 0x40 (64) = COMPRESS                 */
                                     /* 0x80 = ROW MOVEMENT                  */
                                     /* 0x100 = SFT                          */
                                     /* 0x200 = undo retention guarantee     */
                                    /* 0x400 = tablespace belongs to a group */
                                  /* 0x800 = this actually describes a group */
                                   /* 0x1000 = tablespace has MAXSIZE set */
                                   /* 0x2000 = enc property initialized */
                                   /* 0x4000 = encrypted tablespace */
            /* 0x8000 = has its own key and not using the default DB enc key */
                                  /* 0x10000 = OLTP Compression */
                                  /* 0x20000 (131072) = ARCH1_COMPRESSION */
                                  /* 0x40000 (262144) = ARCH2_COMPRESSION */
                                  /* 0x80000 (524288) = ARCH3_COMPRESSION */
  ts_name       varchar2(30)                              /* tablespace name */
)
/

