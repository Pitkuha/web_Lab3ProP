create type ku$_exp_type_body_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  base_obj_num  number,                                /* base object number */
  obj_num       number,                                     /* object number */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  source_lines  ku$_source_list_t,                          /* source lines */
  compiler_info ku$_switch_compiler_t
)
/

