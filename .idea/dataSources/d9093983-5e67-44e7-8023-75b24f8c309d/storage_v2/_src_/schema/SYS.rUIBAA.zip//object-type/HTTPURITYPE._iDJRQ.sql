create type HttpUriType           authid current_user under sys.UriType
(
  -- url varchar2(4000),
  overriding member function getExternalUrl return varchar2 deterministic,
  overriding member function getUrl return varchar2 deterministic,
  -- returns the lob value of the pointed URL
  overriding member function getClob RETURN clob,
  overriding member function getBlob RETURN blob,
  overriding member function getBlob(csid IN NUMBER) RETURN blob,
  static function createUri(httpuri in varchar2) return httpuritype,
  -- new fcns in 9.2
  overriding member function getXML return sys.XMLType,
  constructor function HttpUriType(url in varchar2)
    return self as result,
  overriding member function getContentType RETURN varchar2,
  overriding member function getClob(content OUT varchar2) RETURN clob,
  overriding member function getBlob(content OUT varchar2) RETURN blob,
  overriding member function getXML(content OUT varchar2)
    RETURN sys.XMLType
)
/

