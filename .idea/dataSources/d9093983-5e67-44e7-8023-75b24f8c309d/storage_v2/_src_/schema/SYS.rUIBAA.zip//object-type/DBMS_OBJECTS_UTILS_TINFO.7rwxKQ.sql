create type dbms_objects_utils_tinfo as object (
name       varchar2(30),
objid      number,
toid       raw(16),
hashcode   raw(17),
version    number,
stime      date
);
/

