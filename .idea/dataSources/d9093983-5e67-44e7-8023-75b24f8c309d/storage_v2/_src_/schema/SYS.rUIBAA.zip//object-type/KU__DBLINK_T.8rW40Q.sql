create type ku$_dblink_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  owner_name    varchar2(30),
  owner_num     number,
  name          varchar2(128),
  ctime         varchar2(19),
  host          varchar2(2000),
  userid        varchar2(30),
  password      varchar2(30),
  flag          number,
  authusr       varchar2(30),
  authpwd       varchar2(30),
  passwordx     raw(128),
  authpwdx      raw(128)
)
/

