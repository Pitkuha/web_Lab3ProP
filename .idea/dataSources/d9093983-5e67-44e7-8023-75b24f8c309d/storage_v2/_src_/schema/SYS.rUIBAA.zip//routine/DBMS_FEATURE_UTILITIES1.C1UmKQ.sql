create PROCEDURE dbms_feature_utilities1
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   feature_usage      VARCHAR2(1000) := NULL;
   feature_count      NUMBER := 0;
   compression_count  NUMBER := 0;
   compressbas_count  NUMBER := 0;
   compresslow_count  NUMBER := 0;
   compressmed_count  NUMBER := 0;
   compresshgh_count  NUMBER := 0;
   encryption_count   NUMBER := 0;
   encrypt128_count   NUMBER := 0;
   encrypt192_count   NUMBER := 0;
   encrypt256_count   NUMBER := 0;
   encryptpwd_count   NUMBER := 0;
   encryptdual_count  NUMBER := 0;
   encrypttran_count  NUMBER := 0;
   parallel_count     NUMBER := 0;
   fulltts_count      NUMBER := 0;
BEGIN
  -- initialize
  feature_info      := NULL;

  -- Select stats from ku_utluse.
  begin
    select usecnt, encryptcnt, encrypt128, encrypt192, encrypt256,
           encryptpwd, encryptdual, encrypttran, compresscnt,
           compressbas, compresslow, compressmed, compresshgh, parallelcnt,
           fullttscnt
      into feature_count, encryption_count, encrypt128_count, encrypt192_count,
           encrypt256_count, encryptpwd_count, encryptdual_count,
           encrypttran_count, compression_count, compressbas_count,
           compresslow_count, compressmed_count, compresshgh_count,
           parallel_count, fulltts_count
      from sys.ku_utluse
     where utlname = 'Oracle Utility Datapump (Export)'
       and   (last_used >=
              (SELECT nvl(max(last_sample_date), sysdate-7)
                 FROM dba_feature_usage_statistics));
  exception
    when others then
      null;
  end;

  feature_usage := feature_usage || 'Oracle Utility Datapump (Export) ' ||
                'invoked: ' || feature_count ||
                ' times, compression used: '      || compression_count ||
                ' times (BASIC algorithm used: '  || compressbas_count ||
                ' times, LOW algorithm used: '    || compresslow_count ||
                ' times, MEDIUM algorithm used: ' || compressmed_count ||
                ' times, HIGH algorithm used: '   || compresshgh_count ||
                ' times), encryption used: '      || encryption_count  ||
                ' times (AES128 algorithm used: ' || encrypt128_count  ||
                ' times, AES192 algorithm used: ' || encrypt192_count  ||
                ' times, AES256 algorithm used: ' || encrypt256_count  ||
                ' times, PASSWORD mode used: '    || encryptpwd_count  ||
                ' times, DUAL mode used: '        || encryptdual_count ||
                ' times, TRANSPARENT mode used: ' || encrypttran_count ||
                ' times), parallel used: '        || parallel_count    ||
                ' times, full transportable used: ' || fulltts_count   ||
                ' times';

  feature_info := to_clob(feature_usage);

  feature_boolean := feature_count;
  aux_count       := feature_count;
END dbms_feature_utilities1;
/

