create TYPE     ku$_LogLine1010 IS OBJECT
        (
                logLineNumber   NUMBER,                 -- Line # in log file
                errorNumber     NUMBER,                 -- Error number
                LogText         VARCHAR2(2000)          -- Log entry text
        )
/

