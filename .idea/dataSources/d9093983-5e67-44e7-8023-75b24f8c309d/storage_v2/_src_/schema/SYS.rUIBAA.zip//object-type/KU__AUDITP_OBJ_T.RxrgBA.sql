create type ku$_auditp_obj_t as object (
        ACTION        number,
        audit_obj     ku$_schemaobj_t,              /* object being auditede */
        NAME          varchar2(40)
  )
/

