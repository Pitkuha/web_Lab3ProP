create PROCEDURE load_undo_stat(qlen IN NUMBER, ubks IN NUMBER)
IS
  loadsql varchar2(1024);
  val     number;
  cid     number;
  rows    integer;
BEGIN
  val := ubks * 100000 + qlen + 100;
  loadsql := 'alter system set "_undo_debug_usage" = ' || val;
  dbms_output.put_line(loadsql);
  cid := dbms_sql.open_cursor;
  dbms_sql.parse(cid, loadsql, dbms_sql.native);
  rows := dbms_sql.execute(cid);
  dbms_sql.close_cursor(cid);
END load_undo_stat;
/

