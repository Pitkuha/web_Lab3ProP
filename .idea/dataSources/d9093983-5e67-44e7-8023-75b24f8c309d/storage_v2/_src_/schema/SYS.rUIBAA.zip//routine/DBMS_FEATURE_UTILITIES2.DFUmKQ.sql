create PROCEDURE dbms_feature_utilities2
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   feature_usage      VARCHAR2(1000) := NULL;
   feature_count      NUMBER := 0;
   parallel_count     NUMBER := 0;
   fulltts_count      NUMBER := 0;
BEGIN
  -- initialize
  feature_info := NULL;

  begin
    select usecnt, parallelcnt, fullttscnt
      into feature_count, parallel_count, fulltts_count
      from sys.ku_utluse
     where utlname = 'Oracle Utility Datapump (Import)'
       and   (last_used >=
              (SELECT nvl(max(last_sample_date), sysdate-7)
                 FROM dba_feature_usage_statistics));
  exception
    when others then
      null;
  end;

  feature_usage := feature_usage || 'Oracle Utility Datapump (Import) ' ||
                   'invoked: ' || feature_count ||
                   ' times, parallel used: ' || parallel_count ||
                   ' times, full transportable used: ' || fulltts_count ||
                   ' times';

  feature_info := to_clob(feature_usage);

  feature_boolean := feature_count;
  aux_count       := feature_count;
END dbms_feature_utilities2;
/

