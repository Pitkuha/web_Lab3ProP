create PROCEDURE ODCIColInfoFlagsDump(op NUMBER) IS
BEGIN
   IF (bitand(op, ODCIConst.CompFilterByCol) = ODCIConst.CompFilterByCol) THEN
     dbms_output.put_line('ColInfoFlags : Filter By Column');
   END IF;

   IF (bitand(op, ODCIConst.CompOrderByCol) = ODCIConst.CompOrderByCol) THEN
     IF (bitand(op, ODCIConst.CompOrderDscCol) = ODCIConst.CompOrderDscCol)
          THEN
       dbms_output.put_line('ColInfoFlags : Order By Desc Column');
     ELSE
       dbms_output.put_line('ColInfoFlags : Order By Asc Column');
     END IF;
   END IF;

   IF (bitand(op, ODCIConst.CompUpdatedCol)=ODCIConst.CompUpdatedCol) THEN
     dbms_output.put_line('ColInfoFlags : Updated Column');
   END IF;

   IF (bitand(op, ODCIConst.CompRenamedCol) = ODCIConst.CompRenamedCol) THEN
     dbms_output.put_line('ColInfoFlags : Renamed Column');
   END IF;

   IF (bitand(op,ODCIConst.CompRenamedTopADT)=ODCIConst.CompRenamedTopADT) THEN
     dbms_output.put_line('ColInfoFlags : Renamed Top ADT');
   END IF;

END;
/

