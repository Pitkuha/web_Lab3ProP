create package body sqljutl is

   function has_default(l_owner varchar2,
                        proc varchar2,
                        seq number,
                        ovr varchar2 DEFAULT NULL,
                        pkg_nm varchar2 DEFAULT NULL) return number is
            def char := NULL;
begin
   begin
      if pkg_nm IS NULL
      then
        if ovr is NULL
        then
           select upper(DEFAULTED) INTO def FROM ALL_ARGUMENTS
           WHERE OBJECT_NAME = proc AND OWNER = l_owner
           AND SEQUENCE = seq and OVERLOAD is NULL and PACKAGE_NAME is NULL;
        else
           select upper(DEFAULTED) INTO def FROM ALL_ARGUMENTS
           WHERE OBJECT_NAME = proc AND OWNER = l_owner
           AND SEQUENCE = seq  and OVERLOAD = ovr and PACKAGE_NAME IS NULL;
        end if;
      else
        if ovr is NULL
        then
           select upper(DEFAULTED) INTO def FROM ALL_ARGUMENTS
           WHERE OBJECT_NAME = proc AND OWNER = l_owner
           AND SEQUENCE = seq and OVERLOAD is NULL and PACKAGE_NAME = pkg_nm;
        else
           select upper(DEFAULTED) INTO def FROM ALL_ARGUMENTS
           WHERE OBJECT_NAME = proc AND OWNER = l_owner
           AND SEQUENCE = seq  and OVERLOAD = ovr and PACKAGE_NAME = pkg_nm;
        end if;

      end if;

      EXCEPTION
	WHEN NO_DATA_FOUND THEN
           return 0;
        WHEN OTHERS THEN
           raise_application_error(-20001,'Error - '||SQLCODE||' -ERROR- '||SQLERRM);

   end;

      if def = 'N'
      then return 0;
      else return 1;
      end if;
    return 0;
   end has_default;

   procedure get_typecode
               (tid raw, code OUT number,
                class OUT varchar2, typ OUT number) is
      m NUMBER;
   begin
      SELECT typecode, externname, externtype INTO code, class, typ
      FROM TYPE$ WHERE toid = tid;
   exception
      WHEN TOO_MANY_ROWS
      THEN
      begin
        SELECT max(version#) INTO m FROM TYPE$ WHERE toid = tid;
        SELECT typecode, externname, externtype INTO code, class, typ
        FROM TYPE$ WHERE toid = tid AND version# = m;
      end;
   end get_typecode;

   function bool2int(b BOOLEAN) return INTEGER is
   begin if b is null then return null;
         elsif b then return 1;
         else return 0; end if;
   end bool2int;

   function int2bool(i INTEGER) return BOOLEAN is
   begin if i is null then return null;
         else return i<>0;
         end if;
   end int2bool;

   function ids2char(iv DSINTERVAL_UNCONSTRAINED) return CHAR is
      res CHAR(19);
   begin
      res := iv;
      return res;
   end ids2char;


   function char2ids(ch CHAR) return DSINTERVAL_UNCONSTRAINED is
      iv DSINTERVAL_UNCONSTRAINED;
   begin
      iv := ch;
      return iv;
   end char2ids;

   function iym2char(iv YMINTERVAL_UNCONSTRAINED) return CHAR is
      res CHAR(9);
   begin
      res := iv;
      return res;
   end iym2char;

   function char2iym(ch CHAR) return YMINTERVAL_UNCONSTRAINED is
      iv YMINTERVAL_UNCONSTRAINED;
   begin
      iv := ch;
      return iv;
   end char2iym;

   -- SYS.URITYPE and VARCHAR2
   function uri2vchar(uri SYS.URITYPE) return VARCHAR2 is
   begin
      return uri.geturl;
   end uri2vchar;

end sqljutl;
/

