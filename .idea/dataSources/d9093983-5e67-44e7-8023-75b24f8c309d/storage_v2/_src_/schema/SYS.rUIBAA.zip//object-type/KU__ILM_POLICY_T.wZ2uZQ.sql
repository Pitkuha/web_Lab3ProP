create type ku$_ilm_policy_t as object
(
  obj_num       number,                            /* object number of table */
                                                   /* or ts# of tablespace   */
  policy_num    number,                                     /* policy number */
  ilmobj_flag   number,         /* ilmobj$.flag                              */
                                /* 0x0001 - policy on object disabled        */
                                /* 0x0002 - inherited from schema (not used) */
                                /* 0x0003 - inherited from tablespace        */
                                /* also ilm$.flag if object is tablespace    */
                                /* 0x0001 - policy disabled                  */
                                /* 0x0002 - schema-level policy              */
                                /* 0x0008 - tablespace-level policy          */
                                /* 0x0010 - default policy                   */
  actionc       varchar2(100),                              /* action clause */
  ctype         number,         /* compression type: 2 = OLTP; 3 = row level */
  clevel        number,         /* compression level                         */
                                /*  1 = query low                            */
                                /*  2 = query high                           */
                                /*  3 = archive low                          */
                                /*  4 = archive high                         */
  cindex        number,         /* index compression level                   */
                                               /*  0x0001 prefix compression */
                                          /*  0x0002 OLTP compression high   */
                                          /*  0x0003 OLTP compression low    */
  cprefix       number,   /* Number of columns in case of prefix compression */
  clevlob       number,                             /* LOB compression level */
                                                               /* 0x0001 LOW */
                                                            /* 0x0002 MEDIUM */
                                                              /* 0x0003 HIGH */
  tier_tbs      varchar2(128),                      /* Tablespace to tier to */
  action        number,                            /* type of ILM action     */
                                                   /* 0x0001 Compression     */
                                                   /* 0x0002 Storage tiering */
  type          number,                            /* type code  ??????? */
  condition     number,                   /* condition policy is based on    */
                                          /* 0x0000 - last access time       */
                                          /* 0x0001 - low access             */
                                          /* 0x0002 - last modification time */
                                          /* 0x0003 - creation time          */
  days          number,                                    /* number of days */
  scope         number,                                 /* policy scope      */
                                                        /* 0x0001 -  segment */
                                                        /* 0x0002 -  group   */
                                                        /* 0x0003 -  row     */
  custfunc      varchar2(128),                           /* cust. func. name */
  flag          number,                                      /* policy flags */
                                                      /* 0x0001 -  READ-ONLY */
                                                         /* 0x0002 -  unused */
                                                         /* 0x0004 - inplace */
                                                         /* 0x0008 -  custom */
                                                           /* 0x0010 - GROUP */
                                               /* 0x0020 - Row level locking */
  flag2         number,                             /* flag2 - fields unused */
  spare1        number,                                             /* spare */
  spare2        number,                                             /* spare */
  spare3        number,                                             /* spare */
  spare4        varchar2(4000),                                     /* spare */
  spare5        varchar2(4000),                                     /* spare */
  spare6        timestamp
)
/

