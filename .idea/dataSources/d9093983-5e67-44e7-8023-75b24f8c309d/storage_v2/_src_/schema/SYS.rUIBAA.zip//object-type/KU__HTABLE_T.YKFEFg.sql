create type ku$_htable_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                              /* obj# */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  base_obj      ku$_schemaobj_t,         /* base object (if secondary table) */
  anc_obj       ku$_schemaobj_t,     /* ancestor object (if secondary table) */
  parent_obj    ku$_schemaobj_t,          /* parent object (if refpar child) */
  storage       ku$_storage_t,                                    /* storage */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  ts_name       varchar2(30),                             /* tablespace name */
  blocksize     number,                            /* size of block in bytes */
  dataobj_num   number,                                /* data layer object# */
  bobj_num      number,                           /* base obj# (cluster/iot) */
  tab_num       number,                  /* # in cluster, null if !clustered */
  cols          number,                                      /* # of columns */
  clucols       number,                 /* # of clustered cols, if clustered */
  tabcluster    ku$_tabcluster_t,        /* cluster info, null if !clustered */
  fba           ku$_fba_t, /* flashback archive info, null if not fb enabled */
  fba_period    ku$_fba_period_t,                         /* valid-time info */
  clst          ku$_clst_t,                 /* table clustering info, if any */
  ilm_policies  ku$_ilm_policy_list_t,               /* ilm policies, if any */
  pct_free      number,                   /* min. free space %age in a block */
  pct_used      number,                   /* min. used space %age in a block */
  initrans      number,                     /* initial number of transaction */
  maxtrans      number,                     /* maximum number of transaction */
  flags         number,                                             /* flags */
  audit_val     varchar2(38),                            /* auditing options */
  rowcnt        number,                                    /* number of rows */
  blkcnt        number,                                  /* number of blocks */
  empcnt        number,                            /* number of empty blocks */
  avgspc        number,                      /* average available free space */
  chncnt        number,                            /* number of chained rows */
  avgrln        number,                                /* average row length */
  avgspc_flb    number,       /* avg avail free space of blocks on free list */
  flbcnt        number,                             /* free list block count */
  analyzetime   varchar2(19),                /* timestamp when last analyzed */
  samplesize    number,                 /* number of rows sampled by Analyze */
  degree        number,                       /* # of PQ slaves per instance */
  instances     number,                         /* # of OPS instances for PQ */
  intcols       number,                             /* # of internal columns */
  kernelcols    number,                   /* number of REAL (kernel) columns */
  property      number,                                  /* table properties */
  property2     number,                             /* more table properties */
            /* the table property bits are defined in qcdl.h and kqld.h      */
            /* with names beginning "KQDLTVCP_" and "KQLDTVCP2_"             */
            /* e.g., KQLDTVCP_TTV,  KQLDTVCP2_ILM_MODTR                      */
  /* The low 32 bits of tab$.property are in "property"; "property2" has     */
  /* the high-order bits. Here are the bit definitions of tab$.property:     */
                   /* 0x01 = typed table */
                   /* 0x02 = has ADT columns, */
                   /* 0x04 = has nested-TABLE columns */
                   /* 0x08 = has REF columns, */
                   /* 0x10     (16) = has array columns */
                   /* 0x20     (32) = partitioned table, */
                   /* 0x40     (64) = index-only table (IOT) */
                   /* 0x80    (128) = IOT w/ row OVerflow, */
                   /* 0x100   (256) = IOT w/ row CLustering */
                   /* 0x200   (512) = IOT OVeRflow segment, */
                   /* 0x400  (1024) = clustered table */
                   /* 0x800  (2048) = has internal LOB columns, */
                   /* 0x1000 (4096) = has primary key-based OID$ column */
                   /* 0x2000 (8192) = nested table */
                   /* 0x4000 (16384) = View is Read Only */
                   /* 0x8000 (32768) = has FILE columns */
                   /* 0x10000 (65536) = obj view's OID is sys-generated */
                   /* 0x20000 (131072) = used as AQ table */
                   /* 0x40000 (262144)= has user-defined lob columns */
                   /* 0x80000 (524288)= table contains unused columns */
                   /* 0x100000 (1048576)= has an on-commit materialized view */
                   /* 0x200000 (2097152)= has system-generated column names */
                   /* 0x400000 (4194304)= global temporary table */
                   /* 0x800000 (8388608)= session-specific temporary table */
                   /* 0x8000000 (134217728)= table is a sub table */
                   /* 0x20000000 (536870912) = pdml itl invariant */
                   /* 0x80000000 (2147483648)= table is external  */
  /* property2:                                                              */
  /*  0x000000100000000 (1) - table is a CUBE table                          */
  /*  0x000000400000000 (4) = delayed segment creation                       */
  /*  0x000020000000000 (512) = result cache mode FORCE enabled on this tbl  */
  /*  0x000040000000000 (1024) = result cache mode MANUAL enabled on this tbl*/
  /*  0x000080000000000 (2048) = result cache mode AUTO enabled on this tbl */
  /*  0x020000000000000 (2097152) -                         long varchar col */
  /*  0x00040000000000000   (4194304)-    this table has a clustering clause */
  /*                                        (applies only to the fact table).*/
  /*  0x00080000000000000   (8388608)-   this table has one or more zonemaps */
  /*                                                           defined on it.*/
  /*  0x00400000000000000  (67108864)= has identity column                   */
  /*  0x01000000000000000 (268435456)-     this table appears as a dimension */
  /*                                       in one or more clustering clauses.*/
            /* the table property bits are defined in qcdl.h and kqld.h      */
            /* with names beginning "KQDLTVCP_" and "KQLDTVCP2_"             */
            /* e.g., KQLDTVCP_TTV,  KQLDTVCP2_ILM_MODTR                      */
  xmlschemacols char(1),          /* 'Y' = table has xmlschema-based columns */
  tstz_cols     char(1),                        /* 'Y' = table has TSTZ data */
  xmlcolset     ku$_XmlColSet_t,        /* OR intcolnums for xmltype stoarge */
  xmlhierarchy  char(1),             /* 'Y' = table is xml hierarchy enabled */
  trigflag      number,                              /* inline trigger flags */
  spare1        number,                       /* used to store hakan_kqldtvc */
  spare2        number,         /* committed partition # used by drop column */
  spare3        number,                           /* summary sequence number */
  spare4        varchar2(1000),         /* committed RID used by drop column */
  spare5        varchar2(1000),
  spare6        varchar2(19),                               /* dml timestamp */
  encalg        number,  /* encryption algorithm id if a column is encrypted */
  intalg        number,   /* integrity algorithm id if a column is encrypted */
  col_list      ku$_prim_column_list_t,                   /* list of columns */
  im_colsel     ku$_im_colsel_list_t,           /* inmemory selective column */
  con0_list     ku$_constraint0_list_t,               /* list of constraints */
  con1_list     ku$_constraint1_list_t,               /* list of constraints */
  con2_list     ku$_constraint2_list_t,               /* list of constraints */
  exttab        ku$_exttab_t,                     /* external table metadata */
  cubetab       ku$_cube_tab_t,                /* organization cube metadata */
  refpar_level  number                          /* reference partition level */
)
/

