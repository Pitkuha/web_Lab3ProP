create TYPE CanSyncRefMessage IS OBJECT (
          schema_name        VARCHAR2(30),
          table_name         VARCHAR2(30),
          mv_schema_name     VARCHAR2(30),
          mv_name            VARCHAR2(30),
          eligible           VARCHAR2(1),
          seq_num            NUMBER,
          msg_number         NUMBER,
          message            VARCHAR2(4000));
/

