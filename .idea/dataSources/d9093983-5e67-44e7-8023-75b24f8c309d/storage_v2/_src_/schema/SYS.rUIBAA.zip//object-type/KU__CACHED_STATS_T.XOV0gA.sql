create type ku$_cached_stats_t as object
(
  obj_num       number,
  cachedblk     number,
  cachehit      number
)
/

