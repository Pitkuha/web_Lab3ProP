create type ku$_assoc_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                              /* association object # */
  base_obj      ku$_schemaobj_t,                              /* base object */
  obj_type      number,                                  /* association type */
  objcol        varchar2(30),                          /* association column */
  stats_obj     ku$_schemaobj_t,                            /* statistic obj */
  selectivity   number,                                       /* selectivity */
  cpu_cost      number,                                           /* cpu cost*/
  io_cost       number,                                           /* io cost */
  net_cost      number,                                          /* net cost */
  interface_version number,
  spare2        number
)
/

