create type coad_advice_rec as OBJECT (
     owner       varchar2(30),
     apiObject   varchar2(30),
     sqlObjOwn   varchar2(30),
     sqlObject   varchar2(65),
     adviceType  number(38,0),
     disposition clob,
     sqlText     clob,
     dropText    clob )
/

