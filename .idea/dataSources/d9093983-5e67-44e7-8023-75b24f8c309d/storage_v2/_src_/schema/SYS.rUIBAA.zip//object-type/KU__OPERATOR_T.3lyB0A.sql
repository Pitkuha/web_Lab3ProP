create type ku$_operator_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                            /* operator object number */
  schema_obj    ku$_schemaobj_t,                    /* base schema obj. info */
  property      number,                                    /* property flags */
  bindings      ku$_opbinding_list_t       /* List of bindings for this oper */
)
/

