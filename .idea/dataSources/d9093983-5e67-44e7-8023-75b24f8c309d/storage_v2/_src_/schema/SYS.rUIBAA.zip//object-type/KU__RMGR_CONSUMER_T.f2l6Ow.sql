create type ku$_rmgr_consumer_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,
  schema_obj    ku$_schemaobj_t,
  cpu_method    varchar2(30),      /* CPU resource alloc method for the plan */
  description   varchar2(2000),        /* Text comment on the consumer group */
  status        varchar2(30),                           /* pending or active */
  mandatory     number                                      /* 1:yes , 0: no */
)
/

