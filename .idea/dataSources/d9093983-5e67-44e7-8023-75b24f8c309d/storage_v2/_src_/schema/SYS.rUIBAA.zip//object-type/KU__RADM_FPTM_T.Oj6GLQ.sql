create type ku$_radm_fptm_t as object
(
  vers_major   char(1),                               /* UDT major version # */
  vers_minor   char(1),                               /* UDT minor version # */
  numbercol    number,                                             /* number */
  binfloatcol  binary_float,                                 /* binary float */
  bindoublecol binary_double,                               /* binary double */
  charcol      char(1),                              /* fixed-size character */
  varcharcol   varchar2(1),                       /* variable-size character */
  ncharcol     nchar(1),                    /* fixed-size national character */
  nvarcharcol  nvarchar2(1),             /* variable-size national character */
  datecol      date,                                                 /* date */
  ts_col       timestamp,                                       /* timestamp */
  tswtz_col    timestamp with time zone,         /* timestamp with time zone */
  fpver        number               /* version of default fixed point values */
)
/

