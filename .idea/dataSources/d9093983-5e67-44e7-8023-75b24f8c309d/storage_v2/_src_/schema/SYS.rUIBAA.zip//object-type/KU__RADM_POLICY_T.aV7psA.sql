create type ku$_radm_policy_t as object
(
  vers_major   char(1),                               /* UDT major version # */
  vers_minor   char(1),                               /* UDT minor version # */
  base_obj_num number,                               /* parent object number */
  base_obj     ku$_schemaobj_t,                             /* schema object */
  pname        varchar2(30),                                  /* policy name */
  pexpr        varchar2(4000),                          /* policy expression */
  enable_flag  number,  /* whether the policy is enabled (1) or disabled (0) */
  mc_list      ku$_radm_mc_list_t                    /* column specific data */
)
/

