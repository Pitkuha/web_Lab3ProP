create type dbms_objects_utils_tselem as object (
objid     number,
source    varchar2(4000)
);
/

