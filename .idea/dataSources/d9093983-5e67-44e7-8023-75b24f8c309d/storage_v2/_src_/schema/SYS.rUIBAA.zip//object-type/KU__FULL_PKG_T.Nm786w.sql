create type ku$_full_pkg_t as object
(
  vers_major            char(1),                      /* UDT major version # */
  vers_minor            char(2),                      /* UDT minor version # */
  obj_num               number,                             /* object number */
  schema_obj            ku$_schemaobj_t,                    /* schema object */
  package_t             ku$_proc_t,                        /* package header */
  package_body_t        ku$_proc_t                           /* package body */
)
/

