create type dbms_dbfs_content_context_t
    authid definer
as object (
    principal   varchar2(32),
    acl         varchar2(1024),
    owner       varchar2(32),
    asof        timestamp,
    read_only   integer
);
/

