create type ku$_audit_act_t as object (
        ACTION        number,
        NAME          varchar2(40)
  )
/

