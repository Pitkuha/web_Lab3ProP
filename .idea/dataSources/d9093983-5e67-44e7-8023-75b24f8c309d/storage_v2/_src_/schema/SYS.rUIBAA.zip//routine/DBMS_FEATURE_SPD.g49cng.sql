create PROCEDURE dbms_feature_spd
  (feature_boolean    OUT  NUMBER,
   aux_count          OUT  NUMBER,
   feature_info       OUT  CLOB)
AS
  NEW_LINE      CONSTANT  VARCHAR2(8) := '
';
  num_dirs                NUMBER;   -- number of directives
  plan_dir_mgmt_control   NUMBER;
  dsdir_usage_control     NUMBER;
  spd_retention_weeks     NUMBER;
  num_dir_obj             NUMBER;
  num_dir_subobj          NUMBER;
  tmp_buf                 VARCHAR2(32767);
  CURSOR spd_reason_cursor IS
    select reason c1, count(*) c2 from dba_sql_plan_directives group by reason;
  CURSOR spd_state_cursor IS
    select state c1, count(*) c2 from dba_sql_plan_directives group by state;
  CURSOR spd_type_cursor IS
    select type c1, count(*) c2 from dba_sql_plan_directives group by type;
BEGIN
  -- get total number of rows in dba_sql_plan_directives
  SELECT count(*)
  INTO num_dirs
  FROM dba_sql_plan_directives;

  dbms_lob.createtemporary(feature_info, TRUE);

  -- # of directives with each type
  for spd_type_iter in spd_type_cursor
  loop
    tmp_buf := 'Number of directives with type, '||spd_type_iter.c1||': '||
               spd_type_iter.c2 || NEW_LINE;
    dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);
  end loop;

  -- # of directives with each reason
  for spd_reason_iter in spd_reason_cursor
  loop
    tmp_buf := 'Number of Directives with reason, '||spd_reason_iter.c1||': '||
               spd_reason_iter.c2||NEW_LINE;
    dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);
  end loop;

  -- # of directives with each state
  for spd_state_iter in spd_state_cursor
  loop
    tmp_buf := 'Number of Directives with state, '||spd_state_iter.c1||': '||
               spd_state_iter.c2 || NEW_LINE;
    dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);
  end loop;

  -- # of directive objects and subobjects
  select count(object_name), count(subobject_name)
  into num_dir_obj, num_dir_subobj
  from dba_sql_plan_dir_objects;

  tmp_buf := 'Number of Directive objects: '|| num_dir_obj ||
             ', subobjects: ' || num_dir_subobj || NEW_LINE;
  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  -- # of retention weeks
  select dbms_spd.get_prefs('SPD_RETENTION_WEEKS')
  into spd_retention_weeks
  from dual;

  tmp_buf := 'spd_retention_weeks: '||spd_retention_weeks|| NEW_LINE;
  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  -- get value of _sql_plan_directive_mgmt_control
  select ksppstvl value
  into plan_dir_mgmt_control
  from x$ksppi x, x$ksppcv y where (x.indx = y.indx) and
  ksppinm = '_sql_plan_directive_mgmt_control';

  tmp_buf := '_sql_plan_directive_mgmt_control: ' || plan_dir_mgmt_control
             || NEW_LINE;
  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  -- get value of _optimizer_dsdir_usage_control
  select ksppstvl value
  into dsdir_usage_control
  from x$ksppi x, x$ksppcv y where (x.indx = y.indx) and
  ksppinm = '_optimizer_dsdir_usage_control';

  tmp_buf := '_optimizer_dsdir_usage_control: ' || dsdir_usage_control ||
             NEW_LINE;
  dbms_lob.writeappend(feature_info, length(tmp_buf), tmp_buf);

  -- populate the outputs if some directive mgmt operation is enabled or
  -- if there is atleast one directive.
  if (plan_dir_mgmt_control > 0 or num_dirs > 0) then
    feature_boolean := plan_dir_mgmt_control;
  else
    feature_boolean := 0;
  end if;

  aux_count := num_dirs;

END dbms_feature_spd;
/

