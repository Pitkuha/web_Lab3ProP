create package body     PIDL is


  function pig_tx(obj ptnod, aty ptaty) return varchar2;
    pragma interface(c,pig_tx);
  function pig_nd(obj ptnod, aty ptaty) return ptnod;
    pragma interface(c,pig_nd);
  function pig_u4(obj ptnod, aty ptaty) return ub4;
    pragma interface(c,pig_u4);
  function pig_u2(obj ptnod, aty ptaty) return ub2;
    pragma interface(c,pig_u2);
  function pig_u1(obj ptnod, aty ptaty) return ub1;
    pragma interface(c,pig_u1);
  function pig_s4(obj ptnod, aty ptaty) return sb4;
    pragma interface(c,pig_s4);
  function pig_s2(obj ptnod, aty ptaty) return sb2;
    pragma interface(c,pig_s2);
  function pig_pt(obj ptnod, aty ptaty) return private_ptr_t;
    pragma interface(c,pig_pt);
  function pigsnd(obj ptnod, aty ptaty) return ptseqnd;
    pragma interface(c,pigsnd);

  procedure pip_tx(obj ptnod, val varchar2,   aty ptaty);
    pragma interface(c,pip_tx);
  procedure pip_nd(obj ptnod, val ptnod, aty ptaty);
    pragma interface(c,pip_nd);
  procedure pip_u4(obj ptnod, val ub4,    aty ptaty);
    pragma interface(c,pip_u4);
  procedure pip_u2(obj ptnod, val ub2,    aty ptaty);
    pragma interface(c,pip_u2);
  procedure pip_u1(obj ptnod, val ub1,    aty ptaty);
    pragma interface(c,pip_u1);
  procedure pip_s4(obj ptnod, val sb4,    aty ptaty);
    pragma interface(c,pip_s4);
  procedure pip_s2(obj ptnod, val sb2,    aty ptaty);
    pragma interface(c,pip_s2);
  procedure pip_pt(obj ptnod, val private_ptr_t,  aty ptaty);
    pragma interface(c,pip_pt);
--  procedure pipsnd(obj ptnod, val ptseqnd, aty ptaty);
--    pragma interface(c,pipsnd);

  -- pigeXX : Get sequence element.
  function pigetx(obj ptseqtx, ndx ub2) return varchar2;
    pragma interface(c,pigetx);
  function pigend(obj ptseqnd, ndx ub2) return ptnod;
    pragma interface(c,pigend);
  function pigeu4(obj ptsequ4, ndx ub2) return ub4;
    pragma interface(c,pigeu4);
  function pigeu2(obj ptsequ2, ndx ub2) return ub2;
    pragma interface(c,pigeu2);
  function pigeu1(obj ptsequ1, ndx ub2) return ub1;
    pragma interface(c,pigeu1);
  function piges4(obj ptseqs4, ndx ub2) return sb4;
    pragma interface(c,piges4);
  function piges2(obj ptseqs2, ndx ub2) return sb2;
    pragma interface(c,piges2);
  function pigept(obj ptseqpt, ndx ub2) return private_ptr_t;
    pragma interface(c,pigept);

  -- pipeXX : Put sequence element.
  -- Following put sequence element funcs not yet implemented;
--  procedure pipetx(obj ptseqtx, ndx ub2, val varchar2);
--    pragma interface(c,pipetx);
--  procedure pipend(obj ptseqnd, ndx ub2, val ptnod);
--    pragma interface(c,pipend);
--  procedure pipeu4(obj ptsequ4, ndx ub2, val ub4);
--    pragma interface(c,pipeu4);
--  procedure pipeu2(obj ptsequ2, ndx ub2, val ub2);
--    pragma interface(c,pipeu2);
--  procedure pipeu1(obj ptsequ1, ndx ub2, val ub1);
--    pragma interface(c,pipeu1);
--  procedure pipes4(obj ptseqs4, ndx ub2, val sb4);
--    pragma interface(c,pipes4);
--  procedure pipes2(obj ptseqs2, ndx ub2, val sb2);
--    pragma interface(c,pipes2);
--  procedure pipept(obj ptseqpt, ndx ub2, val private_ptr_t);
--    pragma interface(c,pipept);

  -- misc
  function pidkin(obj ptnod) return ptnty;
    pragma interface(c,pidkin);
  function pidacn(node_enum ptnty) return ub2;
    pragma interface(c,pidacn);
  function pidaty(node_enum ptnty, nth ub2) return ptaty;
    pragma interface(c,pidaty);
  function pidnnm(node_enum ptnty) return varchar2;
    pragma interface(c,pidnnm);
  function pidanm(attr_enum ptaty) return varchar2;
    pragma interface(c,pidanm);
  function pidbty(node_enum ptnty, attr_enum ptaty) return ptbty;
    pragma interface(c,pidbty);
  function pidrty(node_enum ptnty, attr_enum ptaty) return ptrty;
    pragma interface(c,pidrty);
  function pigsln(seq ptseqnd) return ub2;
    pragma interface(c,pigsln);

  function ptkin(obj ptnod) return ptnty is
  begin
    return pidkin(obj);
  end;

  function ptattcnt(node_enum ptnty) return ub2 is
  begin
    return pidacn(node_enum);
  end;

  function ptatttyp(node_enum ptnty, nth ub2) return ptaty is
  begin
    return pidaty(node_enum, nth);
  end;

  function ptattnnm(node_enum ptnty) return varchar2 is
  begin
    return pidnnm(node_enum);
  end;

  function ptattanm(attr_enum ptaty) return varchar2 is
  begin
    return pidanm(attr_enum);
  end;

  function ptattbty(node_enum ptnty, attr_enum ptaty) return ptbty is
  begin
    return pidbty(node_enum, attr_enum);
  end;

  function ptattrty(node_enum ptnty, attr_enum ptaty) return ptrty is
  begin
    return pidrty(node_enum, attr_enum);
  end;

  function ptg_tx(obj ptnod, aty ptaty) return varchar2 is
  begin
    return pig_tx(obj,aty);
  end;

  function ptg_nd(obj ptnod, aty ptaty)
    return ptnod is
  begin
    return pig_nd(obj,aty);
  end;

  function ptg_u4(obj ptnod, aty ptaty) return ub4 is
  begin
    return pig_u4(obj,aty);
  end;

  function ptg_u2(obj ptnod, aty ptaty) return ub2 is
  begin
    return pig_u2(obj,aty);
  end;

  function ptg_u1(obj ptnod, aty ptaty) return ub1 is
  begin
    return pig_u1(obj,aty);
  end;

  function ptg_s4(obj ptnod, aty ptaty) return sb4 is
  begin
    return pig_s4(obj,aty);
  end;

  function ptg_s2(obj ptnod, aty ptaty) return sb2 is
  begin
    return pig_s2(obj,aty);
  end;

  function ptg_pt(obj ptnod, aty ptaty) return ptr_t is
    val ptr_t;
  begin
    val.private_ptr := pig_pt(obj, aty);
    return val;
  end;

  function ptgsnd(obj ptnod,
    aty ptaty) return ptseqnd is
  begin
    return pigsnd(obj,aty);
  end;

  function ptslen(seq ptseqnd) return ub2 is
  begin
    return pigsln(seq);
  end;


  procedure ptp_tx(obj ptnod, val varchar2,
    aty ptaty) is
  begin
    pip_tx(obj,val,aty);
  end;

  procedure ptp_nd(obj ptnod, val ptnod,
    aty ptaty) is
  begin
    pip_nd(obj,val,aty);
  end;

  procedure ptp_u4(obj ptnod, val ub4,
    aty ptaty) is
  begin
    pip_u4(obj,val,aty);
  end;

  procedure ptp_u2(obj ptnod, val ub2,
    aty ptaty) is
  begin
    pip_u2(obj,val,aty);
  end;

  procedure ptp_u1(obj ptnod, val ub1,
    aty ptaty) is
  begin
    pip_u1(obj,val,aty);
  end;

  procedure ptp_s4(obj ptnod, val sb4,
    aty ptaty) is
  begin
    pip_s4(obj,val,aty);
  end;

  procedure ptp_s2(obj ptnod, val sb2,
    aty ptaty) is
  begin
    pip_s2(obj,val,aty);
  end;

  procedure ptp_pt(obj ptnod, val ptr_t,
    aty ptaty) is
  begin
    pip_pt(obj, val.private_ptr, aty);
  end;

--  procedure ptpsnd(obj ptnod, val ptseqnd,
--    aty ptaty) is
--  begin
--    pipsnd(obj,val,aty);
--  end;

  function ptgetx(obj ptseqtx, ndx ub2) return varchar2 is
  begin
    return pigetx(obj,ndx);
  end;

  function ptgend(obj ptseqnd, ndx ub2) return ptnod is
  begin
    return pigend(obj,ndx);
  end;

  function ptgeu4(obj ptsequ4, ndx ub2) return ub4 is
  begin
    return pigeu4(obj,ndx);
  end;

  function ptgeu2(obj ptsequ2, ndx ub2) return ub2 is
  begin
    return pigeu2(obj,ndx);
  end;

  function ptgeu1(obj ptsequ1, ndx ub2) return ub1 is
  begin
    return pigeu1(obj,ndx);
  end;

  function ptges4(obj ptseqs4, ndx ub2) return sb4 is
  begin
    return piges4(obj,ndx);
  end;

  function ptges2(obj ptseqs2, ndx ub2) return sb2 is
  begin
    return piges2(obj,ndx);
  end;

  function ptgept(obj ptseqpt, ndx ub2) return ptr_t is
    val ptr_t;
  begin
    val.private_ptr := pigept(obj, ndx);
    return val;
  end;

--  procedure ptpetx(obj ptseqtx, ndx ub2, val varchar2) is
--  begin
--    pipetx(obj,ndx,val);
--  end;

--  procedure ptpend(obj ptseqnd, ndx ub2, val ptnod) is
--  begin
--    pipend(obj,ndx,val);
--  end;

--  procedure ptpeu4(obj ptsequ4, ndx ub2, val ub4) is
--  begin
--    pipeu4(obj,ndx,val);
--  end;

--  procedure ptpeu2(obj ptsequ2, ndx ub2, val ub2) is
--  begin
--    pipeu2(obj,ndx,val);
--  end;

--  procedure ptpeu1(obj ptsequ1, ndx ub2, val ub1) is
--  begin
--    pipeu1(obj,ndx,val);
--  end;

--  procedure ptpes4(obj ptseqs4, ndx ub2, val sb4) is
--  begin
--    pipes4(obj,ndx,val);
--  end;

--  procedure ptpes2(obj ptseqs2, ndx ub2, val sb2) is
--  begin
--    pipes2(obj,ndx,val);
--  end;

--  procedure ptpept(obj ptseqpt, ndx ub2, val ptr_t) is
--  begin
--    pipept(obj, ndx, val.private_ptr);
--  end;

end pidl;
/

