create PROCEDURE xoq_validate IS
  compat          VARCHAR2(30);
  dummy_num       NUMBER;
  dummy_out_1_str VARCHAR2(100);
  dummy_out_2_str VARCHAR2(100);
  ok              BOOLEAN := TRUE;
  v_Value         varchar2(64);
BEGIN

  begin
    SELECT value INTO v_Value FROM v$option WHERE parameter = 'OLAP';
    if v_Value = 'FALSE' then
      -- set status OPTION OFF
      sys.dbms_registry.Option_Off('XOQ');
      return;
    end if;
  exception
    when OTHERS then
      null;
  end;

  -- check compatible
  SELECT value INTO compat FROM v$parameter WHERE name='compatible';
  IF NOT (substr(compat,1,3) >= '9.2' OR substr(compat,1,2) >= '10') THEN
    ok := FALSE;
  END IF;

  IF ok THEN
    --check for errors during installation/upgrade
    BEGIN
      SELECT 0 INTO dummy_num from sys.registry$error
        WHERE identifier='XOQ'AND rownum <=1;
      -- at least one install error was found so component is invalid
      ok := FALSE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- no install errors were found so component remains valid
        NULL;
    END;
  END IF;

  IF ok THEN
    -- check that dependent component XDB is valid
    IF dbms_registry.is_valid('XDB', dbms_registry.release_version) != 1 THEN
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
   -- check that expected XDB resources are there
    IF NOT (dbms_xdb.existsresource('/olap_data_security/public/acls') AND
            dbms_xdb.existsresource('/xds/dsd')) THEN
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
    -- check that installed library is valid
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_LIBRARIES
        WHERE STATUS = 'INVALID' AND rownum <=1 AND
          OWNER='SYS' AND LIBRARY_NAME = 'DBMS_OLAPI_LIB';
      -- at least one object is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- no invalid objects were found so component remains valid
        NULL;
    END;
  END IF;

  IF ok THEN
    -- check very basic OLAP API function (including load of shared library)
    BEGIN
      dummy_num := OlapiBootstrap2(compat, dummy_out_1_str, dummy_out_2_str);
    EXCEPTION
      WHEN OTHERS THEN
        ok := FALSE;
    END;
  END IF;

  IF ok THEN
    -- check that Java classes are loaded successfully
    BEGIN
      SELECT 0 INTO dummy_num FROM dba_objects
        WHERE owner = 'SYS' AND
             status = 'INVALID' AND
             object_type = 'JAVA CLASS' AND
             object_name LIKE 'oracle/AWXML/%';
      -- at least one class is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- no invalid components were found so component remains valid
      NULL;
    END;
  END IF;

  IF ok THEN
    -- check that installed types, packages, and procedures are valid
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_OBJECTS
        WHERE STATUS = 'INVALID' AND rownum <=1 AND
          OWNER='SYS' AND OBJECT_NAME IN
             ('DBMS_CUBE_ADVISE','DBMS_CUBE_ADVISE_SEC','DBMS_CUBE',
              'DBMS_CUBE_EXP','GENDATABASEINTERFACE','GENCONNECTIONINTERFACE',
              'GENSERVERINTERACE','GENMDMPROPERTYIDCONSTANTS',
              'GENMDMCLASSCONSTANTS','GENMDMOBJECTIDCONSTANTS',
              'GENMETADATAPROVIDERINTERFACE','GENCURSORMANAGERINTERFACE',
              'GENDATATYPEIDCONSTANTS','GENDEFINITIONMANAGERINTERFACE',
              'GENDATAPROVIDERINTERFACE','DBMS_AW_XML','DBMS_CUBE_UTIL',
              'COAD_ADVICE_T','COAD_ADVICE_REC','GENOLAPIEXCEPTION',
              'GENINTERFACESTUB', 'GENINTERFACESTUBSEQUENCE',
              'GENRAWSEQUENCE','GENWSTRINGSEQUENCE',
              'DBMS_CUBE_UTIL_EXT_MD_T','DBMS_CUBE_UTIL_EXT_MD_R',
              'OLAPIHANDSHAKE2','OLAPIBOOTSTRAP2');
      -- at least one object is invalid so component is invalid
      ok := FALSE;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      -- no invalid objects were found so component remains valid
        NULL;
    END;
  END IF;

  IF ok THEN
    -- check for expected role
    BEGIN
      SELECT 0 INTO dummy_num FROM DBA_ROLES
        WHERE ROLE = 'OLAP_XS_ADMIN';
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        ok := FALSE;
    END;
  END IF;

  IF ok THEN
    -- Address bug 17997122 by carefully checking OLAP_XS_ADMIN role
    -- privileges against the DBA_TAB_PRIVS view.
    -- check for privileges granted as local granted privileges, COMMON='NO'
    SELECT COUNT(*) INTO dummy_num
    FROM DBA_TAB_PRIVS
    WHERE GRANTEE='OLAP_XS_ADMIN' AND
          ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
             TABLE_NAME='XS$OLAP_POLICY' AND COMMON='NO') OR
           (PRIVILEGE='SELECT' AND OWNER='SYS' AND
             TABLE_NAME='DBA_ROLES' AND COMMON='NO') OR
           (PRIVILEGE='EXECUTE' AND OWNER='SYS' AND
             TABLE_NAME='DBMS_XDS' AND COMMON='NO'));

    IF dummy_num = 0 THEN
      -- No local granted privileges
      -- check to see if grants are common granted privileges, COMMON = 'YES'
      SELECT COUNT(*) INTO dummy_num
      FROM DBA_TAB_PRIVS
      WHERE GRANTEE='OLAP_XS_ADMIN' AND
            ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='XS$OLAP_POLICY' AND COMMON='YES') OR
             (PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='DBA_ROLES' AND COMMON='YES') OR
             (PRIVILEGE='EXECUTE' AND OWNER='SYS' AND
               TABLE_NAME='DBMS_XDS' AND COMMON='YES'));
      IF dummy_num != 3 THEN
        -- Incomplete set of common granted privileges granted, so invalid
        ok := FALSE;
      END IF;

    ELSIF dummy_num = 3 THEN
      --  Grants are valid for local granted privileges.
      --  Now grants may also be a common granted privilege, COMMON = 'YES'
      SELECT COUNT(*) INTO dummy_num
      FROM DBA_TAB_PRIVS
      WHERE GRANTEE='OLAP_XS_ADMIN' AND
            ((PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='XS$OLAP_POLICY' AND COMMON='YES') OR
             (PRIVILEGE='SELECT' AND OWNER='SYS' AND
               TABLE_NAME='DBA_ROLES' AND COMMON='YES') OR
             (PRIVILEGE='EXECUTE' AND OWNER='SYS' AND
               TABLE_NAME='DBMS_XDS' AND COMMON='YES'));
      IF dummy_num = 0 THEN
        -- No Common granted privileges granted,
        -- but still valid because of valid local granted privileges
        ok := TRUE;
      ELSIF dummy_num != 3 THEN
        -- Incomplete set of common granted privileges granted, so invalid
        ok := FALSE;
      END IF;
    ELSE
      -- Incomplete set of local granted privileges granted, so invalid
      ok := FALSE;
    END IF;
  END IF;

  IF ok THEN
    sys.dbms_registry.valid('XOQ');
  ELSE
    sys.dbms_registry.invalid('XOQ');
  END IF;
END;
/

