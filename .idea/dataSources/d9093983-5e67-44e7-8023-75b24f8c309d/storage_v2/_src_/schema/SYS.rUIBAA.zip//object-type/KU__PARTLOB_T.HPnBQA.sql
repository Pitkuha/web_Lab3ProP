create type ku$_partlob_t as object
(
  obj_num       number,                                /* obj# of base table */
  intcol_num    number,                            /* internal column number */
  schema_obj    ku$_schemaobj_t,            /* LOB schema object (for lobj#) */
  defts_name    varchar2(30),                     /* default tablespace name */
  defblocksize  number,                    /* default size of block in bytes */
  defchunk      number,                    /* oracle blocks in one lob chunk */
  defpctversion number,                              /* default version pool */
  defflags      number,                                             /* flags */
                                                 /* 0x0001 = NOCACHE LOGGING */
                                               /* 0x0002 = NOCACHE NOLOGGING */
                                             /* 0x0008 = CACHE READS LOGGING */
                                           /* 0x0010 = CACHE READS NOLOGGING */
  defpro        number,                        /* default partition property */
                                             /* 0x02 = enable storage in row */
  definiexts    number,  /* default INITIAL extent size; NULL if unspecified */
  defextsize    number,     /* default NEXT extent size; NULL if unspecified */
  defminexts    number,           /* default MINEXTENTS; NULL if unspecified */
  defmaxexts    number,           /* default MAXEXTENTS; NULL if unspecified */
  defextpct     number,          /* default PCTINCREASE; NULL if unspecified */
  deflists      number,      /* default FREELISTS value; NULL if unspecified */
  defgroups     number,      /* default FREELIST GROUPS; NULL if unspecified */
  defbufpool    number,          /* default BUFFER_POOL; NULL if unspecified */
  spare1        number,
  spare2        number,
  spare3        number,
  defmaxsize    number,              /* default MAXSIZE; NULL if unspecified */
  defretention  number,            /* default RETENTION; NULL if unspecified */
  defmintime    number    /* default MIN retention time; NULL if unspecified */
)
/

