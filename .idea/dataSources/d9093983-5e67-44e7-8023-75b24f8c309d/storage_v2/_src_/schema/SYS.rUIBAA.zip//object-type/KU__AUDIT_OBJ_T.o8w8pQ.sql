create type ku$_audit_obj_t as object
(
  vers_major    char(1),
  vers_minor    char(1),
  obj_num       number,                                     /* object number */
  base_obj      ku$_schemaobj_t,                          /* base obj schema */
  audit_val     varchar2(38),                            /* auditing options */
  audit_list    sys.ku$_audit_list_t                           /* audit list */
)
/

