create PROCEDURE     validate_ordim
authid current_user
IS
 l_null char(1);
 b_valid       boolean := TRUE;           -- keep track installation status
                                          -- TRUE: valid (default),
                                          -- FALSE: invalid
 l_num_objects integer     :=0;
 l_num_classes integer     :=0;
 l_num_schemas integer     :=0;
 l_num_docs    integer     :=0;
 l_num_roles   integer     :=0;
 l_num_errors  number      :=0;
 err_code NUMBER;
 err_msg  VARCHAR2(100);
 l_prevDbVer varchar2(40);
 l_status  varchar2(100);
 l_dsql_block varchar2(500);
 l_sdo_status varchar2(20) := NULL;
 b_upgradeMode boolean     := FALSE;

BEGIN
  -- Now check whether Multimedia objects are created
  begin
    select count(*) into l_num_objects from sys.obj$ o, sys.user$ u
      where u.name = 'ORDSYS'
        and u.user# = o.owner#
        and o.type# = 13
        and o.name in
            ( 'ORDIMAGE', 'ORDAUDIO', 'ORDDOC', 'ORDVIDEO', 'ORDDICOM',
              'SI_COLOR', 'SI_STILLIMAGE', 'SI_AVERAGECOLOR',
              'SI_COLORHISTOGRAM', 'SI_POSITIONALCOLOR', 'SI_TEXTURE',
              'SI_FEATURELIST'
            )
    ;

    if ( l_num_objects != 12 ) then
      b_valid := FALSE;
      dbms_output.put_line('ORDIM created ' || l_num_objects || ' objects.');
      dbms_output.put_line('The following objects are not created:');

      for r in (
      (
        select 'ORDIMAGE' name from dual
        union
        select 'ORDAUDIO' name from dual
        union
        select 'ORDDOC' name from dual
        union
        select 'ORDVIDEO' name from dual
        union
        select 'ORDDICOM' name from dual
        union
        select 'SI_COLOR' name from dual
        union
        select 'SI_STILLIMAGE' name from dual
        union
        select 'SI_AVERAGECOLOR' name from dual
        union
        select 'SI_COLORHISTOGRAM' name from dual
        union
        select 'SI_POSITIONALCOLOR' name from dual
        union
        select 'SI_TEXTURE' name from dual
        union
        select 'SI_FEATURELIST' name from dual
      )
      minus
      (
        select o.name from sys.obj$ o, sys.user$ u
        where u.name = 'ORDSYS'
          and u.user# = o.owner#
          and o.type# = 13
          and o.name in
              ( 'ORDIMAGE', 'ORDAUDIO', 'ORDDOC', 'ORDVIDEO', 'ORDDICOM',
                'SI_COLOR', 'SI_STILLIMAGE', 'SI_AVERAGECOLOR',
                'SI_COLORHISTOGRAM', 'SI_POSITIONALCOLOR', 'SI_TEXTURE',
                'SI_FEATURELIST'
              )
      ) ) loop
        dbms_output.put_line(r.name);
      end loop;

    end if;

  exception
    WHEN NO_DATA_FOUND THEN
      b_valid := FALSE;
      dbms_output.put_line('ORDIM objects are not created.');

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  end;

  -- Now check whether Multimedia java classes are loaded
  -- The following jars are checked:
  --  mlibwrapper_jai.jar, jai_codec.jar, jai_core.jar, ordimimg.jar
  --  ordimdcm.jar, ordimann.jar
  begin
    select count(*) into l_num_classes
      from sys.obj$ o, sys.user$ u, sys.javasnm$ j
      where u.name = 'ORDSYS'
        and u.user# = o.owner#
        and o.type# = 29
        and j.short(+) = o.name
        and nvl(j.longdbcs, o.name) in
            ( 'javax/media/jai/JAI', 'com/sun/media/jai/codec/ImageCodec',
              'com/sun/medialib/mlib/mediaLibImage', 'oracle/ord/media/img/PropsAdapter',
              'oracle/ord/dicom/attr/DicomAttrTag',
              'oracle/ord/media/annotator/servclt/AnnCltInServer'
            )
    ;

    if ( l_num_classes != 6 ) then
      b_valid := FALSE;
      dbms_output.put_line('The following ORDIM Java libs are not loaded correctly:');

      for r in (
      (
        select 'javax/media/jai/JAI' name, 'jai_core.jar' jar from dual
        union
        select 'com/sun/media/jai/codec/ImageCodec' name, 'jai_codec.jar' jar from dual
        union
        select 'com/sun/medialib/mlib/mediaLibImage' name, 'mlibwrapper_jai.jar' jar from dual
        union
        select 'oracle/ord/media/img/PropsAdapter' name, 'ordimimg.jar' jar from dual
        union
        select 'oracle/ord/dicom/attr/DicomAttrTag' name, 'ordimdcm.jar' jar from dual
        union
        select 'oracle/ord/media/annotator/servclt/AnnCltInServer' name, 'ordimann.jar' jar from dual
      )
      minus
      (
        select nvl(j.longdbcs, o.name) name,
          decode( nvl(j.longdbcs, o.name) , 'javax/media/jai/JAI', 'jai_core.jar',
                    'com/sun/media/jai/codec/ImageCodec', 'jai_codec.jar',
                    'com/sun/medialib/mlib/mediaLibImage', 'mlibwrapper_jai.jar',
                    'oracle/ord/media/img/PropsAdapter', 'ordimimg.jar',
                    'oracle/ord/dicom/attr/DicomAttrTag', 'ordimdcm.jar',
                    'oracle/ord/media/annotator/servclt/AnnCltInServer', 'ordimann.jar') jar
          from sys.obj$ o, sys.user$ u, sys.javasnm$ j
          where u.name = 'ORDSYS'
            and u.user# = o.owner#
            and o.type# = 29
            and j.short(+) = o.name
            and nvl(j.longdbcs, o.name) in
                ( 'javax/media/jai/JAI', 'com/sun/media/jai/codec/ImageCodec',
                  'com/sun/medialib/mlib/mediaLibImage', 'oracle/ord/media/img/PropsAdapter',
                  'oracle/ord/dicom/attr/DicomAttrTag',
                  'oracle/ord/media/annotator/servclt/AnnCltInServer'
                )
      ) ) loop
        dbms_output.put_line(r.jar);
      end loop;
    end if;

  exception
    WHEN NO_DATA_FOUND THEN
      b_valid := FALSE;
      dbms_output.put_line('ORDIM java classes are not loaded.');

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  end;


  -- Now check whether there are invalid objects
  BEGIN
    SELECT NULL INTO l_null  FROM sys.dba_invalid_objects
    WHERE
          (owner = 'ORDSYS'
        OR owner = 'ORDPLUGINS'
        OR owner = 'SI_INFORMTN_SCHEMA'
        OR owner = 'ORDDATA')
       AND rownum <= 1;

    -- invalid objects found
    b_valid := FALSE;

    FOR ob IN (SELECT o.object_name, o.status, o.object_type
               FROM sys.dba_invalid_objects o
        WHERE
              (o.owner = 'ORDSYS'
            OR o.owner = 'ORDPLUGINS'
            OR o.owner = 'SI_INFORMTN_SCHEMA'
            OR o.owner = 'ORDDATA')
            AND rownum < 20) LOOP
      dbms_output.put_line ('ORDIM INVALID OBJECTS: ' || ob.object_name || ' - ' || ob.status || ' - ' || ob.object_type);
    END LOOP;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- no valid objects, don't need to do anything
      null;

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  END;

  -- Now check whether XML schemas are registered
  begin
    select count(*) into l_num_schemas from sys.all_xml_schemas
      where owner = 'ORDSYS'
        and schema_url in
            (
             'http://xmlns.oracle.com/ord/meta/ordimage',
             'http://xmlns.oracle.com/ord/meta/exif',
             'http://xmlns.oracle.com/ord/meta/iptc',
             'http://xmlns.oracle.com/ord/meta/xmp',
             'http://xmlns.oracle.com/ord/meta/dicomImage',
             'http://xmlns.oracle.com/ord/dicom/rpdatatype_1_0',
             'http://xmlns.oracle.com/ord/dicom/datatype_1_0',
             'http://xmlns.oracle.com/ord/dicom/mddatatype_1_0',
             'http://xmlns.oracle.com/ord/dicom/anonymity_1_0',
             'http://xmlns.oracle.com/ord/dicom/attributeTag_1_0',
             'http://xmlns.oracle.com/ord/dicom/constraint_1_0',
             'http://xmlns.oracle.com/ord/dicom/metadata_1_0',
             'http://xmlns.oracle.com/ord/dicom/mapping_1_0',
             'http://xmlns.oracle.com/ord/dicom/manifest_1_0',
             'http://xmlns.oracle.com/ord/dicom/preference_1_0',
             'http://xmlns.oracle.com/ord/dicom/privateDictionary_1_0',
             'http://xmlns.oracle.com/ord/dicom/standardDictionary_1_0',
             'http://xmlns.oracle.com/ord/dicom/orddicom_1_0',
             'http://xmlns.oracle.com/ord/dicom/UIDdefinition_1_0'
          )
    ;

    if ( l_num_schemas != 19 ) then
      b_valid := FALSE;
      dbms_output.put_line('ORDIM registered ' || l_num_schemas || ' XML schemas.');
      dbms_output.put_line('The following XML schemas are not registered:');

      for r in (
      (
        select 'http://xmlns.oracle.com/ord/meta/ordimage' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/meta/exif' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/meta/iptc' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/meta/xmp' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/meta/dicomImage' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/rpdatatype_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/datatype_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/mddatatype_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/anonymity_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/attributeTag_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/constraint_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/metadata_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/mapping_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/manifest_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/preference_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/privateDictionary_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/standardDictionary_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/orddicom_1_0' schema_url from dual
        union
        select 'http://xmlns.oracle.com/ord/dicom/UIDdefinition_1_0' schema_url from dual
      )
      minus
      (
        select schema_url from sys.all_xml_schemas
          where owner = 'ORDSYS'
            and schema_url in
                (
                 'http://xmlns.oracle.com/ord/meta/ordimage',
                 'http://xmlns.oracle.com/ord/meta/exif',
                 'http://xmlns.oracle.com/ord/meta/iptc',
                 'http://xmlns.oracle.com/ord/meta/xmp',
                 'http://xmlns.oracle.com/ord/meta/dicomImage',
                 'http://xmlns.oracle.com/ord/dicom/rpdatatype_1_0',
                 'http://xmlns.oracle.com/ord/dicom/datatype_1_0',
                 'http://xmlns.oracle.com/ord/dicom/mddatatype_1_0',
                 'http://xmlns.oracle.com/ord/dicom/anonymity_1_0',
                 'http://xmlns.oracle.com/ord/dicom/attributeTag_1_0',
                 'http://xmlns.oracle.com/ord/dicom/constraint_1_0',
                 'http://xmlns.oracle.com/ord/dicom/metadata_1_0',
                 'http://xmlns.oracle.com/ord/dicom/mapping_1_0',
                 'http://xmlns.oracle.com/ord/dicom/manifest_1_0',
                 'http://xmlns.oracle.com/ord/dicom/preference_1_0',
                 'http://xmlns.oracle.com/ord/dicom/privateDictionary_1_0',
                 'http://xmlns.oracle.com/ord/dicom/standardDictionary_1_0',
                 'http://xmlns.oracle.com/ord/dicom/orddicom_1_0',
                 'http://xmlns.oracle.com/ord/dicom/UIDdefinition_1_0'
              )
      ) ) loop
        dbms_output.put_line(r.schema_url);
      end loop;

    end if;

  exception
    WHEN NO_DATA_FOUND THEN
      b_valid := FALSE;
      dbms_output.put_line('ORDIM XML schemas are not registered.');

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  end;

  -- Now check whether default documents are inserted into the DICOM repository
  begin
    select count(*) into l_num_docs from orddata.orddcm_docs
      where doc_name in
          (
            'ordcman.xml',
            'ordcmcmc.xml',
            'ordcmcmd.xml',
            'ordcmct.xml',
            'ordcmmp.xml',
            'ordcmpf.xml',
            'ordcmpv.xml',
            'ordcmsd.xml',
            'ordcmui.xml'
          )
    ;

    if ( l_num_docs != 9 ) then
      b_valid := FALSE;
      dbms_output.put_line('ORDIM DICOM repository has ' || l_num_docs || ' documents.');
      dbms_output.put_line('The following default DICOM repository documents are not installed:');

      for r in (
      (
        select 'ordcman.xml' doc_name from dual
        union
        select 'ordcmcmc.xml' doc_name from dual
        union
        select 'ordcmcmd.xml' doc_name from dual
        union
        select 'ordcmct.xml' doc_name from dual
        union
        select 'ordcmmp.xml' doc_name from dual
        union
        select 'ordcmpf.xml' doc_name from dual
        union
        select 'ordcmpv.xml' doc_name from dual
        union
        select 'ordcmsd.xml' doc_name from dual
        union
        select 'ordcmui.xml' doc_name from dual
      )
      minus
      (
        select doc_name from orddata.orddcm_docs
          where doc_name in
            (
              'ordcman.xml',
              'ordcmcmc.xml',
              'ordcmcmd.xml',
              'ordcmct.xml',
              'ordcmmp.xml',
              'ordcmpf.xml',
              'ordcmpv.xml',
              'ordcmsd.xml',
              'ordcmui.xml'
            )
      ) ) loop
        dbms_output.put_line(r.doc_name);
      end loop;

    end if;

  exception
    WHEN NO_DATA_FOUND THEN
      b_valid := FALSE;
      dbms_output.put_line('ORDIM default DICOM repository documents are not installed.');

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  end;

  -- Now check whether DICOM ORDADMIN role is created
  begin
    SELECT count(*) INTO l_num_roles  FROM sys.user$ u
    WHERE type# = 0 and name = 'ORDADMIN';

    if ( l_num_roles != 1 ) then
      b_valid := FALSE;
      dbms_output.put_line('ORDIM DICOM administrator role ORDADMIN is not created.');
    end if;

  exception
    when no_data_found then
      b_valid := FALSE;
      dbms_output.put_line('ORDIM DICOM administrator role ORDADMIN is not created.');

    when others then
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  end;

  -- Check whether Locator is valid if SDO is not installed or is OPTION OFF
  -- by checking whether there are invalid objects under MDSYS
  BEGIN
    l_sdo_status := dbms_registry.status('SDO');
    if (l_sdo_status is NULL or l_sdo_status = 'OPTION OFF' or
        l_sdo_status = 'REMOVED') then
      SELECT NULL INTO l_null  FROM sys.dba_invalid_objects
      WHERE
            owner = 'MDSYS'
        AND rownum <= 1;

      -- invalid objects found
      b_valid := FALSE;

      FOR ob IN (SELECT o.object_name, o.status, o.object_type
                 FROM sys.dba_invalid_objects o
          WHERE
                o.owner = 'MDSYS'
            AND rownum < 20) LOOP
        dbms_output.put_line ('Locator INVALID OBJECTS: ' || ob.object_name || ' - ' || ob.status || ' - ' || ob.object_type);
      END LOOP;
    end if;

  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      -- no valid objects, don't need to do anything
      null;

    WHEN OTHERS THEN
      b_valid := FALSE;
      err_code := SQLCODE;
      err_msg  := SUBSTR(SQLERRM, 1 , 100);
      DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
  END;

--
-- verify that data from ordsys has been moved to orddata
-- Note: this check is performed only if upgrading from 11.1
--  and the status is 'UPGRADED'

  begin
    select prv_version into l_prevDbVer
    from sys.registry$ where cid='ORDIM';

    l_status := sys.dbms_registry.status('ORDIM');

    if (l_prevDbVer = '11.1.0') and (l_status = 'UPGRADED') then
    begin
      -- Dynamic sql is used for compilation purposes because the
      -- ordsys.orddcm_docs table will not exist for new installations
      -- or if not upgrading from 11.1.0 database.
      -- check for documents in ORDSYS schema
      execute immediate 'select count(*) into l_num_docs from ordsys.orddcm_docs
          where doc_name in
              (
                ''ordcman.xml'',
                ''ordcmcmc.xml'',
                ''ordcmcmd.xml'',
                ''ordcmct.xml'',
                ''ordcmmp.xml'',
                ''ordcmpf.xml'',
                ''ordcmpv.xml'',
                ''ordcmsd.xml'',
                ''ordcmui.xml''
              );';
      if (l_num_docs <> 9 ) then
        dbms_output.put_line('ORDSYS DICOM repos: '
                              || 'expected: 9 got: '
                              || l_num_docs || ' default docs');
      end if;

     exception
      WHEN NO_DATA_FOUND THEN
        dbms_output.put_line('ORDSYS DICOM repository documents are not installed.');

      WHEN OTHERS THEN
        err_code := SQLCODE;
        err_msg  := SUBSTR(SQLERRM, 1 , 100);
        DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
     end;


     BEGIN
       --
       -- Expect no differences between the ORDSYS and ORDDATA repos
       --
       l_dsql_block := 'BEGIN
             for cur in (select doc_name from ordsys.orddcm_docs
                  minus select doc_name from orddata.orddcm_docs) loop
               dbms_output.put_line(''ORDSYS doc: ''
                            || cur.doc_name || '' not in ORDDATA'');
             end loop;
           end;';

       execute immediate l_dsql_block;

       l_dsql_block := 'BEGIN
            for cur in ( select doc_name from orddata.orddcm_docs
                    minus select doc_name from ordsys.orddcm_docs) loop
               dbms_output.put_line(''ORDData doc: ''
                              || cur.doc_name || '' not in ORDSYS'');
            end loop;
          END;';

       execute immediate l_dsql_block;


     exception

      WHEN OTHERS THEN
        b_valid := FALSE;
        err_code := SQLCODE;
        err_msg  := SUBSTR(SQLERRM, 1 , 100);
        DBMS_OUTPUT.put_line('In validate_ordim OTHER EXCEPTION happens: Error code ' || err_code || ': ' || err_msg);
    END;
   end if;

  END;

  --
  -- Finally, if in upgrade mode, check if there are errors in registry$error
  --
  b_upgradeMode := sys.dbms_registry.is_in_upgrade_mode();
  if b_upgradeMode then
    l_num_errors := sys.dbms_registry.count_errors_in_registry('ORDIM');
    if (l_num_errors > 0) then
      dbms_output.put_line
       ('There were ' || l_num_errors ||
        ' entries in sys.registry$error for ORDIM');
      b_valid := FALSE;
    end if;
  end if;

  --
  -- Set the registry status at the end
  --
  if NOT b_valid then
    sys.dbms_registry.invalid('ORDIM');
  else
    sys.dbms_registry.valid('ORDIM');
  end if;

END;
/

