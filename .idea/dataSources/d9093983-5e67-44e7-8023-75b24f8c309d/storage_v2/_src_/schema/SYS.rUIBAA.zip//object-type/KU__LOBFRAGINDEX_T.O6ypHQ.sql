create type ku$_lobfragindex_t as object
(
  obj_num       number,                                          /* object # */
  schema_obj    ku$_schemaobj_t,                            /* schema object */
  ts_name       varchar2(30),                                  /* tablespace */
  blocksize     number,                            /* size of block in bytes */
  storage       ku$_storage_t,                                    /* storage */
  deferred_stg  ku$_deferred_stg_t,                      /* deferred storage */
  dataobj_num   number,                          /* data layer object number */
  base_obj_num  number,                                        /* base index */
  part_num      number,                                  /* partition number */
  flags         number,                                     /* mutable flags */
  pct_free      number,          /* minimum free space percentage in a block */
  pct_thres     number,           /* iot overflow threshold, null if not iot */
  initrans      number,                     /* initial number of transaction */
  maxtrans      number,                    /* maximum number of transactions */
  analyzetime   varchar2(19),                /* timestamp when last analyzed */
  samplesize    number,                 /* number of rows sampled by Analyze */
  rowcnt        number,                       /* number of rows in the index */
  blevel        number,                                       /* btree level */
  leafcnt       number,                                  /* # of leaf blocks */
  distkey       number,                                   /* # distinct keys */
  lblkkey       number,                          /* avg # of leaf blocks/key */
  dblkkey       number,                          /* avg # of data blocks/key */
  clufac        number,                                 /* clustering factor */
  spare1        number,
  spare2        number,
  spare3        number,
  inclcol       number                     /* iot include col#, null if !iot */
)
/

