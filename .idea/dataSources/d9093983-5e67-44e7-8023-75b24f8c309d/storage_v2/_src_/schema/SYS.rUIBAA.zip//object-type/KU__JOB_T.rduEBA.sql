create type ku$_job_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  powner_id     number,                                          /* owner id */
  powner        varchar2(30),                                  /* owner name */
  lowner        varchar2(30),                              /* logged in user */
  cowner        varchar2(30),                                    /* parsing  */
  job_id        number,                                           /* job id  */
  last_date     varchar2(19),                /* when this job last succeeded */
  this_date     varchar2(19),   /* when current execute started,usually null */
  next_date     varchar2(19),                /* when to execute the job next */
  flag          number,                          /* 0x01, this job is broken */
  failures      number,             /* number of failures since last success */
  interval_num  varchar2(400),                /* function for next next_date */
  what          clob,                        /* PL/SQL text, what is the job */
  nlsenv        clob,                                      /* nls parameters */
  env           raw(32),                      /* other environment variables */
  field1        number,            /* instance number restricted to run  job */
  charenv       varchar2(4000)                /* Reserved for Trusted Oracle */
)
/

