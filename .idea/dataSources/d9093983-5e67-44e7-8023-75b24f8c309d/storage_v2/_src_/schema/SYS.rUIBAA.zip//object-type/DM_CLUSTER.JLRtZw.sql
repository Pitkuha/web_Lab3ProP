create type dm_cluster
                                       as object
  (id                    number
  ,cluster_id            varchar2(4000)
  ,record_count          number
  ,parent                number
  ,tree_level            number
  ,dispersion            number
  ,split_predicate       dm_predicates
  ,child                 dm_children
  ,centroid              dm_centroids
  ,histogram             dm_histograms
  ,rule                  dm_rule)
/

