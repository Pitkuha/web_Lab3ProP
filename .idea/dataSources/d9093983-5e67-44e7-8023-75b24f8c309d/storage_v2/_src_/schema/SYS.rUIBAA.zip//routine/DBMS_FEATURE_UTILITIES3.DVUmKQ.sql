create PROCEDURE dbms_feature_utilities3
     ( feature_boolean  OUT  NUMBER,
       aux_count        OUT  NUMBER,
       feature_info     OUT  CLOB)
AS
   feature_usage      VARCHAR2(1000) := NULL;
   feature_count      NUMBER := 0;
BEGIN
  -- initialize
  feature_info      := NULL;

  begin
    select usecnt into feature_count from sys.ku_utluse
      where utlname = 'Oracle Utility Metadata API'
       and   (last_used >=
             (SELECT nvl(max(last_sample_date), sysdate-7)
               FROM dba_feature_usage_statistics));
  exception
    when others then
      null;
  end;

  feature_boolean := feature_count;
  aux_count       := feature_count;
END dbms_feature_utilities3;
/

