create type dbms_cube_util_dflt_msr_r
  as object (owner             varchar2(128),
             cube_name         varchar2(128),
             default_measure   varchar2(128) )
/

