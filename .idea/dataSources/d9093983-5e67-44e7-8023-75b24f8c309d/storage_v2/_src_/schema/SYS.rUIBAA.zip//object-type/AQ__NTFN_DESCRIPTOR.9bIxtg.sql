create TYPE     aq$_ntfn_descriptor AS OBJECT (
        ntfn_flags         number)                     -- flags
/

