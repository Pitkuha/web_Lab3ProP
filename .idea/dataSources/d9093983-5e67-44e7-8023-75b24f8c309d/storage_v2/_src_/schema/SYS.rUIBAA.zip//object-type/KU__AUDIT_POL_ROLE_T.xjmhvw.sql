create type ku$_audit_pol_role_t as object (
  role_num        number,
  role_name       varchar2(128)
  )
/

