create type dbms_objects_utils_tname as object (
schema  varchar2(128),
typname varchar2(128)
);
/

