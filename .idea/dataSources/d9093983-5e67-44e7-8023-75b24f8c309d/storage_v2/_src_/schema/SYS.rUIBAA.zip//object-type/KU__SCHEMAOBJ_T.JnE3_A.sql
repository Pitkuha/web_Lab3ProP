create type ku$_schemaobj_t as object
(
  obj_num       number,                                     /* object number */
  dataobj_num   number,                          /* data layer object number */
  owner_num     number,                                 /* owner user number */
  owner_name    varchar2(30),                                  /* owner name */
  name          varchar2(30),                                 /* object name */
  namespace     number,                               /* namespace of object */
  subname       varchar2(30),                     /* subordinate to the name */
  type_num      number,                                       /* object type */
  type_name     varchar2(30),                            /* object type name */
  ctime         varchar2(19),                        /* object creation time */
  mtime         varchar2(19),                       /* DDL modification time */
  stime         varchar2(19),           /* specification timestamp (version) */
  status        number,                                  /* status of object */
  remoteowner   varchar2(30),           /* remote owner name (remote object) */
  linkname      varchar2(128),                  /* link name (remote object) */
  flags         number,                                             /* flags */
    /* flag definitions from kqd.h */
    /* KQDOBFDOM  0x01                                                      */
    /* KQDOBTMP   0x02                                  object is temporary */
    /* KQDOBFGEN  0x04                           object is system generated */
    /* KQDOBFUNB  0x08              object is unbound (has invokers rights) */
    /* KQDOBSCO   0x10                                   secondary object - */
                                   /* currently only used for domain indexes */
    /* KQDOBIMT   0x20                                 in-memory temp table */
    /* KQDOBFPKJ  0x40                          permanently kept java class */
    /* KQDOBRBO   0x80                                Object in Recycle Bin */
    /* KQDOBSYP   0x100                            synonym has VPD policies */
    /* KQDOBGRP   0x200                              synonym has VPD groups */
    /* KQDOBCVX   0x400                             synonym has VPD context */
    /* KQDOBCRD   0x800                           object is cursor duration */
/* NOTE: Flags 0x1000 - 0xf000 are reserved for object invalidation reasons */
    /* KQDOBFITE  0x1000               object's dependency type has evolved */
    /* KQDOBDFV   0x2000                            Disable fast validation */

                                    /*Using these two flags for misc purposes*/
    /* KQDOBNTP   0x4000                  object is a nested table parition */
    /* KQDOBOBERR 0x8000                           object has objerror$ row */

    /* KQDOBF_MD_LINK  0x10000    Metadata Link or a Metadata-Linked Object */
    /* KQDOBF_OBJ_LINK 0x20000        Object Link or a Object-Linked Object */
    /* KQDOBF_COMMON_OBJECT (KQDOBF_MD_LINK | KQDOBF_OBJ_LINK)

    /* KQDOBLID   0x40000                     object uses a long identifier */
    /* KQDOBFASTTABUPG 0x80000               allow fast alter table upgrade */
    /* KQDOBNE    0x100000            object marked not editionable by user */
    /* KQDOSIVK   0x200000                special invoker rights: see kkxrca */
    /* KQDOBORCL  0x400000                      is an Oracle-supplied object */
    /* KQDONFD    0x800000                    no fine-grained dep for object */
  oid           raw(16),        /* OID for typed table, typed view, and type */
  spare1        number,
  spare2        number,
  spare3        number,                              /* 11.2 original owner# */
  spare4        varchar2(1000),
  spare5        varchar2(1000),
  spare6        varchar2(19),
  owner_name2   varchar2(30),                    /* 11.2 original owner_name */
  signature     raw(16),
  spare7        number,
  spare8        number,
  spare9        number
)
/

