create type dm_model_setting
                                       as object
  (setting_name          varchar2(30)
  ,setting_value         varchar2(128))
/

