create type ku$_monitor_t as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                                /* base object number */
  base_obj      ku$_schemaobj_t,                       /* base schema object */
  monitor       number                              /* 1: enable, 0: disable */
)
/

